import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class StudentManagement
{
	static Scanner in = new Scanner(System.in);
	StudentDAO studentDAO = new StudentDAO();
	
	public void addNewStudent()
	{
		try
		{
			System.out.print("Enter the Student first name: ");
			String f_name = in.next();
			System.out.print("Enter the Student second name: ");
			String l_name = in.next();
			System.out.print("Enter the Student date of birth(dd/mm/yyyy): ");
			String dob = in.next();
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date date = formatter.parse(dob);
			System.out.println("\n1.Male\n2.Female\nEnter Gender: ");
			int n = in.nextInt();
			Gender g = null;
			if(n==1)
			{
				g = Gender.MALE;
			}
			else if(n==2)
			{
				g = Gender.FEMALE;
			}
			in.nextLine();
			System.out.print("Enter the address :");
			String add = in.nextLine();
			studentDAO.getAllClass();
			studentDAO.getAllSection();
			System.out.print("Enter the Student class id: ");
			int cls_id = in.nextInt();
			System.out.print("Enter the section class id: ");
			int sec_id = in.nextInt();
			
			Student newStudent = new Student(f_name, l_name, date, g, add);
			studentDAO.addStudent(newStudent, cls_id, sec_id);
			System.out.println("New student added with ID: " + newStudent.getStudentId());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void showAllStudent()
	{
		List<Student> allStudents = studentDAO.getAllStudents();
		System.out.println("All Students:");
		for (Student student : allStudents) 
		{
			System.out.println("Student ID: " + student.getStudentId() +
						", Name: " + student.getFirstName() + " " + student.getLastName() +
						", Date of Birth: " + student.getDateOfBirth() +
						", Gender: " + student.getGender() +
						", Address: " + student.getAddress());
		}
	}
	
	public void showStudentNames()
	{
		List<Student> allStudents = studentDAO.getAllStudents();
		System.out.println("All Students Name With Id:");
		for (Student student : allStudents) 
		{
			System.out.println("Student ID: " + student.getStudentId() +
						", Name: " + student.getFirstName() + " " + student.getLastName());
		}
	}
	
	
}
