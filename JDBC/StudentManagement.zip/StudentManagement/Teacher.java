public class Teacher
{
	private int teacherId;
	private String firstName;
	private String lastName;
	private Date dateOfBirth;
	private String gender;
	private String subjectTaught;

	public Teacher(String firstName, String lastName, Date dateOfBirth, String gender, String subjectTaught) 
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.subjectTaught = subjectTaught;
	}
}
