import java.util.List;
import java.util.Scanner;
import java.sql.Date;

public class Main
{
	static Scanner in = new Scanner(System.in);
	
	public static void main(String []args)
	{
		StudentManagement sm = new StudentManagement();
		while(true)
		{
			System.out.print("1.Add Student\n2.Show Student\n3.Add Teacher\n4.Show Teacher\n5.Show Student Marks\n6.Show Student Full Info\n7.Exit\n");
			System.out.print("Enter the Option to perform :");	
			int n = in.nextInt();
			switch(n)
			{
				case 1:
					sm.addNewStudent();
					break;
				
				case 2:
					sm.showAllStudent();
					break;
					
				case 3:
					//sm.addNewTeacher();
					break;
					
				case 4:
					//sm.showAllTeacher();
					break;
					
				case 7:
					System.exit(0);
			}
		}
	}
}
