public class Bomb extends Characters{

    static int range = 1;

    Bomb(Position p){
        super('X',p);
    }
}
