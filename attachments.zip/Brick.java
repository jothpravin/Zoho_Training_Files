public class Brick extends Characters{
    Brick(Position p){
        super('B',p);
    }
}
