public class Wall extends Characters{
    Wall(Position p){
        super('*', p);
    }

    Wall(){
        super('*', null);
    }
}
