public class Villian extends Characters{
    Villian(Position p){
        super('V', p);
    }
}
