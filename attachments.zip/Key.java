public class Key extends Characters{
    Key(Position p){
        super('K', p);
    }
}
