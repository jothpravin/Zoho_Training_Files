import java.util.Scanner;

public class LongestSubString
{
	static boolean IsDuplicate(char ch[], int start, int end)
	{
		for(int i=start; i<end; i++)
		{
			for(int j=start+1; j<end; j++)
			{
				if(ch[i]==ch[i+1])
				{
					return true;
				}
			}
		}
		return false;
	}
	public static void main(String []args)
	{
		String Word;
		int count=0, end=0, max=0;
		char ch[];
		Scanner str = new Scanner(System.in);
		System.out.print("Enter the String : ");
		Word = str.nextLine();
		
		ch = Word.toCharArray();
		
		for(int i=0; i<ch.length; i++)
		{
			count =1;
			end = i;
			for(int j=i+1; j<ch.length; j++)
			{
				if(ch[i]!=ch[j])
				{
					count++;
					end = j;
				}
				else
				{
					break;
				}
			}
			if(IsDuplicate(ch, i, end))
			{
				if(count>max)
				{
					max=count;
				}	
			}
		}
		System.out.println("The Longest Substring is "+max);
	}
}
