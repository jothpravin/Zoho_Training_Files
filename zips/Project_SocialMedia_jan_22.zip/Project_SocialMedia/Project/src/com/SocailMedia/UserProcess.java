package SocailMedia;

interface UserProcess
{

}
