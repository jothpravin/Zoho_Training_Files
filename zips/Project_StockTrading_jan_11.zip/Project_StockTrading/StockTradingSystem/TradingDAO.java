package StockTradingSystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TradingDAO 
{
    static int TradingAccountID;
    Connection con = ConnectionDB.getConnection();
    public List<Stock> showAllStocks()
    {
        List<Stock> stocks = new ArrayList<>();
        String query = "SELECT * FROM stocks";
        try(PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery()) 
        {
            while(rs.next())
            {
                Stock stock = new Stock(rs.getString("stockname"), rs.getDouble("stockprice"));
                stocks.add(stock);
            }
            return stocks;
        } 
        catch(SQLException e) 
        {
            e.printStackTrace();
        }
        return null;
    }
}
