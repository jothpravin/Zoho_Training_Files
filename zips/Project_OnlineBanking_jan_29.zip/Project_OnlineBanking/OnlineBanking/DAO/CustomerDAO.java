package OnlineBanking.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

import OnlineBanking.Model.Customer;
import OnlineBanking.Utils.ConnectionDB;;

public class CustomerDAO 
{
    public static int CUSTOMER_ID;
	static Connection con = null;
	public CustomerDAO()
	{
		con = ConnectionDB.getConnection();
	}

    public void CreateCustomer(Customer customer) 
    {
        String query = "INSERT INTO customer (firstname, lastname, email, gender, date_of_birth, street_address, city, state_name, zip_code)"+
                        "values (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try(PreparedStatement ps = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS))
        {
            Date sqlDate = new Date(customer.getDob().getTime());
            ps.setString(1, customer.getFirstName());
            ps.setString(2, customer.getLastName());
            ps.setString(3, customer.getEmail());
            ps.setObject(4, customer.getGender(), Types.OTHER);
            ps.setDate(5, sqlDate);
            ps.setString(6, customer.getStreetAddress());
            ps.setString(7, customer.getCity());
            ps.setString(8, customer.getState());
            ps.setInt(9, customer.getPincode());

            int row = ps.executeUpdate();
            if(row > 0)
            {
                ResultSet rs = ps.getGeneratedKeys();
                if(rs.next())
                {
                    customer.setCustomerId(rs.getInt(1));
                    System.out.println("Successfully new customer account created");
                }
            }

        }
        catch(SQLException e)
        {
            System.out.println(e.getMessage());
        }
    }   
}