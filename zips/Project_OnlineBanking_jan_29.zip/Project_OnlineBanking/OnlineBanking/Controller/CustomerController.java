package OnlineBanking.Controller;

import OnlineBanking.DAO.CustomerDAO;
import OnlineBanking.Model.Customer;
import OnlineBanking.View.CustomerView;

public class CustomerController 
{
    private CustomerDAO customerDAO;
    private CustomerView customerView;
    public CustomerController(CustomerDAO customerDAO, CustomerView customerView)
    {
        this.customerDAO = customerDAO;
        this.customerView = customerView;
    }

    public void newCustomer()
    {
        Customer customer = customerView.newCustomer();
        customerDAO.CreateCustomer(customer); 
    }

    public void newAccount()
    {
        
    }
}
