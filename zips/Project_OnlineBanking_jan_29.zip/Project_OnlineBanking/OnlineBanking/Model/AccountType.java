package OnlineBanking.Model;

public enum AccountType 
{
    Savings,
    Current
}
