package OnlineBanking.Model;

public enum TransactionType 
{
    Credit,
    Debit
}
