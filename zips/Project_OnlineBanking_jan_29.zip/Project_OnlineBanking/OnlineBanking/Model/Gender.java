package OnlineBanking.Model;

public enum Gender 
{
    Male,
    Female
}
