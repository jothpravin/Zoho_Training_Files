import java.util.List;
import java.util.Scanner;
import java.sql.Date;

public class Main
{
	static Scanner in = new Scanner(System.in);
	
	public static void main(String []args)
	{
		StudentManagement sm = new StudentManagement();
		while(true)
		{
			System.out.println("------------------------------------------------------");
			System.out.println("| Option |            Description                    |");
			System.out.println("------------------------------------------------------");
			System.out.println("|   1    | Add Student                               |");
			System.out.println("|   2    | Show Student                              |");
			System.out.println("|   3    | Add Teacher                               |");
			System.out.println("|   4    | Show Teacher                              |");
			System.out.println("|   5    | Add Student Marks                         |");
			System.out.println("|   6    | Show Student Full Info                    |");
			System.out.println("|   7    | Show Student Marks                        |");
			System.out.println("|   8    | Add Subjects                              |");
			System.out.println("|   9    | Exit                                      |");
			System.out.println("------------------------------------------------------");

			System.out.print("Enter the Option to perform :");	
			int n = in.nextInt();
			switch(n)
			{
				case 1:
					sm.addNewStudent();
					break;
				
				case 2:
					sm.showAllStudents();
					break;
					
				case 3:
					sm.addNewTeacher();
					break;
					
				case 4:
					sm.showAllTeachers();
					break;
					
				case 5:
					sm.addStudentMarks();
					break;	
					
				case 6:
					sm.showStudentInfo();
					break;
					
				case 7:
					sm.showStudentMarks();
					break;
					
				case 8:
					sm.addSubject();
					break;
					
				case 9:
					System.exit(0);
			}
		}
	}
}
