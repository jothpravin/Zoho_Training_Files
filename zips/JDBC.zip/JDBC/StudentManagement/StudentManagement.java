import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

class StudentManagement
{
	static Scanner in = new Scanner(System.in);
	StudentDAO studentDAO = new StudentDAO();
	TeacherDAO teacherDAO = new TeacherDAO();
	
	public void addNewStudent()
	{
		try
		{
			System.out.print("Enter the Student first name: ");
			String f_name = in.next();
			System.out.print("Enter the Student second name: ");
			String l_name = in.next();
			System.out.print("Enter the Student date of birth(dd/mm/yyyy): ");
			String dob = in.next();
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date date = formatter.parse(dob);
			System.out.println("\n1.Male\n2.Female\nEnter Gender: ");
			int n = in.nextInt();
			Gender g = null;
			if(n==1)
			{
				g = Gender.MALE;
			}
			else if(n==2)
			{
				g = Gender.FEMALE;
			}
			in.nextLine();
			System.out.print("Enter the address :");
			String add = in.nextLine();
			showClass();
			System.out.print("Enter the Student class id: ");
			int cls_id = in.nextInt();
			showSections();
			System.out.print("Enter the Student section id: ");
			int sec_id = in.nextInt();
			
			Student newStudent = new Student(f_name, l_name, date, g, add);
			studentDAO.addStudent(newStudent, cls_id, sec_id);
			System.out.println("New student added with ID: " + newStudent.getStudentId());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void addNewTeacher()
	{
		try
		{
			System.out.print("Enter the Teacher first name: ");
			String f_name = in.next();
			System.out.print("Enter the Teacher second name: ");
			String l_name = in.next();
			System.out.print("Enter the Teacher date of birth(dd/mm/yyyy): ");
			String dob = in.next();
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date date = formatter.parse(dob);
			System.out.println("\n1.Male\n2.Female\nEnter Gender: ");
			int n = in.nextInt();
			Gender g = null;
			if(n==1)
			{
				g = Gender.MALE;
			}
			else if(n==2)
			{
				g = Gender.FEMALE;
			}
			showSubjects();
			System.out.print("Enter the Subject Id :");
			int sub = in.nextInt();
			String subj = selectSubject(sub);
			System.out.print("Enter the Degree:");
			String deg = in.next();
			System.out.print("Enter the Category:");
			String cat = in.next();
			showClass();
			System.out.print("Enter the Student class id: ");
			int cls_id = in.nextInt();
			showSections();
			System.out.print("Enter the section class id: ");
			int sec_id = in.nextInt();
			Teacher teacher = new Teacher(f_name, l_name, date, g, subj, deg, cat);
			teacherDAO.addTeacher(teacher, cls_id, sec_id);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void addStudentMarks()
	{
		List<Subject> subject = teacherDAO.getAllSubjects();
		int count = subject.size();
		try
		{
			showStudentNames();
			System.out.print("Enter the Student Id :");
			int sub = in.nextInt();
			for(int i=0; i<count; i++)
			{
				System.out.print("Enter the "+subject.get(i).getSubjectName()+" mark :");
				int subMark = in.nextInt();
				Marks m = new Marks(sub, subject.get(i).getSubId(), subMark);
				studentDAO.addStudentMarks(m);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void addSubject()
	{
		System.out.print("Enter the Subject Name :");
		String sub = in.next();
		
		Subject subject = new Subject(sub);
		teacherDAO.addSubject(subject);
	}
	
	public void showAllStudents() 
	{
		List<Student> allStudents = studentDAO.getAllStudents();

		System.out.println("All Students:");
		System.out.printf("%-10s %-20s %-12s %-8s %-50s\n", "Student ID", "Name", "Date of Birth", "Gender", "Address");
		System.out.println("------------------------------------------------------------");

		for (Student student : allStudents) 
		{
			System.out.printf("%-10d %-20s %-12s %-8s %-50s\n",
			student.getStudentId(),
			student.getFirstName() + " " + student.getLastName(),
			student.getDateOfBirth(),
			student.getGender(),
			student.getAddress());
		}
	}

	
	public void showAllTeachers() 
	{
		List<Teacher> allTeachers = teacherDAO.getAllTeachers();

		System.out.println("All Teachers:");
		System.out.printf("%-12s %-20s %-12s %-8s %-20s %-20s %-10s\n",
		"Teacher ID", "Name", "Date of Birth", "Gender", "Subject Taught", "Degree", "Category");
		System.out.println("--------------------------------------------------------------------------------------------");

		for (Teacher teacher : allTeachers) 
		{
			System.out.printf("%-12d %-20s %-12s %-8s %-20s %-20s %-10s\n",
			teacher.getTeacherId(),
			teacher.getFirstName() + " " + teacher.getLastName(),
			teacher.getDateOfBirth(),
			teacher.getGender(),
			teacher.getSubjectTaught(),
			teacher.getDegree(),
			teacher.getCategory());
		}
	}

	
	public void showStudentMarks()
	{
		Map<String, ArrayList<String>> studentRec = studentDAO.getStudentMarks();
		
		System.out.println("------------------------------------------------------------------");
		for(Map.Entry<String, ArrayList<String>> entry : studentRec.entrySet())
		{
			System.out.println(entry.getKey());
			ArrayList<String> rec = entry.getValue();
			for(String s : rec)
			{
				System.out.println(s);
			}  
			System.out.println("------------------------------------------------------------------");
		}
	}
	
	public void showStudentInfo()
	{
		List<String> allInfo = studentDAO.getAllStudentInfo();
		System.out.println("All Students detailed info:");
		
		System.out.println("------------------------------------------------------------------");
		for(String s : allInfo)
		{
			System.out.println(s);
			System.out.println("------------------------------------------------------------------");
		}
		
	}
	
	public void showStudentNames()
	{
		List<Student> allStudents = studentDAO.getAllStudents();
		System.out.println("All Students Name With Id:");
		for (Student student : allStudents) 
		{
			System.out.println("Student ID: " + student.getStudentId() +
						", Name: " + student.getFirstName() + " " + student.getLastName());
		}
	}
	
	private void showClass()
	{
		List<Class> cls = studentDAO.getAllClass();
		System.out.println("All classes :");
		for(Class cc : cls)
		{
			System.out.println("Class ID: " + cc.getClassId() +
							"  Name: " + cc.getClassName());
		}
	}
	
	private void showSections()
	{
		List<Section> sec = studentDAO.getAllSection();
		System.out.println("All Sections :");
		for(Section s : sec)
		{
			System.out.println("Section ID: " + s.getSectionId() +
							"  Name: " + s.getSectionName());
		}
	}
	
	
	private void showSubjects()
	{
		List<Subject> sub = teacherDAO.getAllSubjects();
		System.out.println("All Subjects :");
		for(Subject s: sub)
		{
			System.out.println("Subject ID: " + s.getSubId() +
							"  Name: " + s.getSubjectName());
		}
	}
	
	private String selectSubject(int sub)
	{
		List<Subject> s = teacherDAO.getAllSubjects();
		for(Subject ss : s)
		{
			if(ss.getSubId() == sub)
				return ss.getSubjectName();
		}
		return null;
	}
	
	
	
}
