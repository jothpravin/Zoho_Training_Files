import java.sql.Date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.List;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Types;

class TeacherDAO
{
	private static final String teacher_insert = "INSERT INTO teachers (first_name, last_name, date_of_birth, gender, subject_taught, degree, category) VALUES(?,?,?,?,?,?,?)";
	private static final String teacher_class_sec_query = "INSERT INTO teacher_class_section_mapping VALUES (?, ?, ?)";
	private static final String teacher_select_query = "SELECT * FROM teachers";
	private static final String subjects_select_query = "SELECT * FROM subjects";
	private static final String subject_insert_query = "INSERT INTO subjects (subject_name) VALUES (?)";
	
	public void addTeacher(Teacher t, int cls, int sec)
	{
		try(Connection con = ConnectionDB.getConnection();
		    PreparedStatement ps = con.prepareStatement(teacher_insert, Statement.RETURN_GENERATED_KEYS))
		{
			Date sqlDate = new Date(t.getDateOfBirth().getTime());
			ps.setString(1, t.getFirstName());
			ps.setString(2, t.getLastName());
			ps.setDate(3, sqlDate);
			ps.setObject(4, t.getGender(), Types.OTHER);
			ps.setString(5, t.getSubjectTaught());
			ps.setString(6, t.getDegree());
			ps.setString(7, t.getCategory());
			
			int row = ps.executeUpdate();
			if(row > 0)
			{
				ResultSet rs = ps.getGeneratedKeys();
				if(rs.next())
				{
					t.setTeacherId(rs.getInt(1));
					System.out.println("Successfully inserted into teacher table");
				}
			}
		}
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		try(Connection con = ConnectionDB.getConnection();
		    PreparedStatement ps = con.prepareStatement(teacher_class_sec_query))
		{
			ps.setInt(1, t.getTeacherId());
			ps.setInt(2, cls);
			ps.setInt(3, sec);
			
			int row = ps.executeUpdate();
			if(row > 0)
			{
				System.out.println("Successfully inserted into teacher class mapping table");
			}
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void addSubject(Subject s)
	{
		try(Connection con = ConnectionDB.getConnection();
		    PreparedStatement ps = con.prepareStatement(subject_insert_query))
		{
			ps.setString(1, s.getSubjectName());
			
			int row = ps.executeUpdate();
			if(row > 0)
			{
				System.out.println("Successfully inserted into subject table");
			}
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
	}
	
	public List<Teacher> getAllTeachers() 
	{
		List<Teacher> teachers = new ArrayList<>();

		try(Connection connection = ConnectionDB.getConnection();
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(teacher_select_query)) 
		{

			while(resultSet.next()) 
			{
				Teacher teacher = new Teacher(
									resultSet.getString("first_name"),
									resultSet.getString("last_name"),
									resultSet.getDate("date_of_birth"),
									Gender.valueOf(resultSet.getString("gender")),
									resultSet.getString("subject_taught"),
									resultSet.getString("degree"),
									resultSet.getString("category")
									);
				teacher.setTeacherId(resultSet.getInt("teacher_id"));
				teachers.add(teacher);
			}

		} 
		catch(SQLException e) 
		{
			e.printStackTrace();
		}

		return teachers;
	}
	
	public List<Subject> getAllSubjects()
	{
		List<Subject> subjects = new ArrayList<>();
		
		try(Connection connection = ConnectionDB.getConnection();
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(subjects_select_query)) 
		{

			while(resultSet.next()) 
			{
				Subject subject = new Subject(resultSet.getString("subject_name"));
				subject.setSubId(resultSet.getInt("subject_id"));
				subjects.add(subject);
			}

		} 
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		return subjects;
		
	}
}
