import java.util.ArrayList;

public class StackImp<T>
{
	ArrayList<T> s = new ArrayList<>();
	public void push(T a)
	{
		s.add(a);
	}
	public T peek()
	{
		return s.get(s.size()-1);
	}
	public T pop()
	{
		T temp = s.get(s.size()-1);
		s.remove(s.size()-1);
		return temp;	
	}
	public void display()
	{
		System.out.println(s);
	}
	public static void main(String []args)
	{
		StackImp<String> st = new StackImp<>();
		st.push("Pravin");
		st.push("Jain");
		st.push("Jaya");
		st.push("Banu");
		st.display();
		System.out.println(st.peek());
		System.out.println(st.pop());
		st.display();
	}
}
