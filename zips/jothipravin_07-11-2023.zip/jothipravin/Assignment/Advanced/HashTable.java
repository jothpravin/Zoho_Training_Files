import java.util.ArrayList;
import java.util.LinkedList;

class KeyValuePair<K, V> 
{
    private K key;
    private V value;

    public KeyValuePair(K key, V value) 
    {
        this.key = key;
        this.value = value;
    }

    public K getKey() 
    {
        return key;
    }

    public V getValue() 
    {
        return value;
    }
    public void setValue(V value)
    {
    	  this.value = value;
    }
}

public class HashTable<K, V> 
{
    private ArrayList<LinkedList<KeyValuePair<K, V>>> table;
    private int capacity;
    private int size;

    public HashTable(int initialCapacity) 
    {
        this.capacity = initialCapacity;
        this.size = 0;
        this.table = new ArrayList<>(capacity);
        for (int i = 0; i < capacity; i++) 
        {
            table.add(new LinkedList<>());
        }
    }

    private int hashFunction(K key) 
    {
        return Math.abs(key.hashCode()) % capacity;
    }

    public void put(K key, V value) 
    {
        int index = hashFunction(key);
        LinkedList<KeyValuePair<K, V>> list = table.get(index);

        for (KeyValuePair<K, V> pair : list) 
        {
            if (pair.getKey().equals(key)) 
            {
                pair.setValue(value); // Update the value if the key already exists
                return;
            }
        }

        list.add(new KeyValuePair<>(key, value));
        size++;

        if ((1.0 * size) / capacity > 0.7) 
        {    
            resizeTable();
        }
    }

    public V get(K key) 
    {
        int index = hashFunction(key);
        LinkedList<KeyValuePair<K, V>> list = table.get(index);

        for (KeyValuePair<K, V> pair : list) 
        {
            if (pair.getKey().equals(key)) 
            {
                return pair.getValue();
            }
        }

        return null; // Key not found
    }

    public void remove(K key) 
    {
        int index = hashFunction(key);
        LinkedList<KeyValuePair<K, V>> list = table.get(index);

        for (KeyValuePair<K, V> pair : list) 
        {
            if (pair.getKey().equals(key)) 
            {
                list.remove(pair);
                size--;
                return;
            }
        }
    }

    private void resizeTable() 
    {
        ArrayList<LinkedList<KeyValuePair<K, V>>> oldTable = table;
        capacity *= 2;
        size = 0;

        table = new ArrayList<>(capacity);
        for (int i = 0; i < capacity; i++) 
        {
            table.add(new LinkedList<>());
        }

        for (LinkedList<KeyValuePair<K, V>> list : oldTable) 
        {
            for (KeyValuePair<K, V> pair : list) 
            {
                put(pair.getKey(), pair.getValue());
            }
        }
    }
    
    public void print() 
    {
        for (int i = 0; i < capacity; i++) 
        {
            LinkedList<KeyValuePair<K, V>> list = table.get(i);
            if (!list.isEmpty()) 
            {
                System.out.print("Bucket " + i + ": ");
                for (KeyValuePair<K, V> pair : list) 
                {
                    System.out.print("(" + pair.getKey() + ", " + pair.getValue() + ") ");
                }
                System.out.println();
            }
        }
    }
    
    public boolean search(K key)
    {
         return get(key)!=null ? true : false;
    }

    public static void main(String[] args) 
    {
        HashTable<String, Integer> ht = new HashTable<>(10);

        ht.put("one", 1);
        ht.put("two", 2);
        ht.put("three", 3);
        ht.put("four", 4);
        ht.put("five", 5);
        ht.put("six", 6);
        ht.put("seven", 7);
        ht.put("eight", 8);
        ht.put("nine", 9);
        ht.put("ten", 10);

        System.out.println("Value for key 'one': " + ht.get("one"));
        System.out.println("Value for key 'two': " + ht.get("two"));
        System.out.println("Value for key 'four': " + ht.get("four"));
        System.out.println("Searching for key 'four': " + ht.search("four"));
        System.out.println("Searching for key 'four': " + ht.search("fou"));


        ht.remove("two");
        System.out.println("Value for key 'two' after removal: " + ht.get("two"));
        ht.put("one", 1);
        ht.print();
    }
}

