import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.Queue;
import java.util.LinkedList;

public class Graph
{
	private Map<Integer, List<Integer>> adjacentList;
	
	public Graph()
	{
		adjacentList = new HashMap<>();
	}
	
	public void addVertex(int vertex)
	{
		if(!adjacentList.containsKey(vertex))
		{
			adjacentList.put(vertex , new ArrayList<>());
		}
	}
	
	public void removeVertex(int vertex)
	{
		if(adjacentList.containsKey(vertex))
		{
			adjacentList.remove(vertex);
		}
		
		for(int v: adjacentList.keySet())
		{
			adjacentList.get(v).removeIf(neighbour -> neighbour==vertex);
		}
	}
	
	public void addEdge(int source, int destination)
	{
		if(adjacentList.containsKey(source) && adjacentList.containsKey(destination))
		{
			adjacentList.get(source).add(destination);
			adjacentList.get(destination).add(source);
		}
	}
	
	public void removeEdge(int source, int destination)
	{
		if(adjacentList.containsKey(source) && adjacentList.containsKey(destination))
		{
			adjacentList.get(source).remove(Integer.valueOf(destination));
			adjacentList.get(destination).remove(Integer.valueOf(source));
		}
	}
	
	public void bfs(int vertex)
	{
		Queue<Integer> q = new LinkedList<>();
		boolean [] visited = new boolean[adjacentList.size()];
		q.offer(vertex);
		visited[vertex] = true;
		
		while(!q.isEmpty())
		{
			int v = q.poll();
			System.out.print(v+" ");
			
			List<Integer> neigh = adjacentList.get(v);
			for(int n : neigh)
			{
				if(visited[n] == false)
				{
					q.offer(n);
					visited[n] = true;
				}
			}
		}
	}
	
	public static void main(String []args)
	{
		Graph graph = new Graph();
		graph.addVertex(0);
		graph.addVertex(1);
		graph.addVertex(2);
            graph.addVertex(3);
		graph.addVertex(4);

		graph.addEdge(0, 1);
		graph.addEdge(0, 2);
		graph.addEdge(1, 3);
		graph.addEdge(2, 3);
		graph.addEdge(2, 4);

		graph.removeEdge(2, 3);	
		graph.removeVertex(4);	
		
		System.out.println("Breadth-First Search starting from vertex 0:");
		graph.bfs(0);
		System.out.println();
		//System.out.println("Breadth-First Search starting from vertex 4:");
		//graph.bfs(4);
		
	}
}
