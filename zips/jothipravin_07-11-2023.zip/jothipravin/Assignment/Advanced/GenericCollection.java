import java.util.ArrayList;
import java.util.List;

class Custom
{
	private String name;
	
	public Custom(String name)
	{
		this.name = name;
	}
	
	public String toString()
	{
		return "CustomObject{name ="+name+"}";
	}
}

public class GenericCollection<T>
{
	private List<T> elements = new ArrayList<>();
	
	public void addElements(T a)
	{
		elements.add(a);
	}

	public List<T> getElements()
	{
		return elements;
	}
	
	public void printElements()
	{
		for(T element : elements)
		{
			System.out.println(element);
		}
	}

	public static void main(String []args)
	{
		GenericCollection<Object> gc = new GenericCollection<>();
		
		gc.addElements("Pravin");
		gc.addElements('J');
		gc.addElements(3);
		gc.addElements(true);
		gc.addElements(new Custom("Pravin"));

		System.out.println(gc.getElements());	
	}
}
