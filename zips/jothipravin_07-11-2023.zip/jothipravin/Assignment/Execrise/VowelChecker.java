import java.util.Scanner;

public class VowelChecker {
    public static boolean containsVowel(String input) {
        // Convert the input string to lowercase for a case-insensitive check.
        input = input.toLowerCase();

        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                return true; // Found a vowel, so return true.
            }
        }
        return false; // No vowel found in the string.
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String userInput = scanner.nextLine();

        boolean hasVowel = containsVowel(userInput);

        if (hasVowel) {
            System.out.println("The string contains at least one vowel.");
        } else {
            System.out.println("The string does not contain any vowels.");
        }

        // Don't forget to close the scanner when you're done with it.
        scanner.close();
    }
}
