public class check
{
	static void d()
	{
		return;
	}
	static double j()
	{
		int a=20,b=10;
		z
		return Math.sqrt(a+5);
	}
	public static void main(String []args)
	{
		d();
		System.out.println(j());	
	}
}
