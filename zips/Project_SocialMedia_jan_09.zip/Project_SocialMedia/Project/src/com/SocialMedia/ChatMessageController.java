public class ChatMessageController 
{
    ChatMessageDAO chatMessageDAO = new ChatMessageDAO();

    public void sendNewMessage()
    {
        
    }
}
