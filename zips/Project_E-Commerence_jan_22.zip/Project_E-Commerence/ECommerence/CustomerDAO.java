package ECommerence;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

public class CustomerDAO
{
	static int CUSTOMER_ID;
	static Connection con = ConnectionDB.getConnection();
	public void addCustomer(Customer customer)
	{
		String query = "INSERT INTO customers (firstname, lastname, gender, email, password, mobile, wallet) VALUES (?, ?, ?, ?, ?, ?, ?)";
		try(PreparedStatement ps = con.prepareStatement(query))
		{
			ps.setString(1, customer.getFirstName());
			ps.setString(2, customer.getLastName());
			ps.setObject(3, customer.getGender(), Types.OTHER);
			ps.setString(4, customer.getEmail());
			ps.setString(5, customer.getPassword());
			ps.setLong(6, customer.getMobile_no());
			ps.setLong(7, customer.getWallet());
			
			int row = ps.executeUpdate();
			if(row > 0)
			{
				System.out.println("Successfully New Customer Account Created..!");
			}
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public Customer getCustomer()
	{
		String query = "SELECT * FROM customers WHERE customerid = ?";
		try(PreparedStatement ps = con.prepareStatement(query))
		{
			ps.setInt(1, CUSTOMER_ID);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				Customer customer = new Customer(rs.getString("firstname"),
									   rs.getString("lastname"),
									   Gender.valueOf(rs.getString("gender")),
									   rs.getString("email"),
									   rs.getString("password"),
									   rs.getLong("mobile"),
									   rs.getLong("wallet")
									);
				customer.setCustomerId(rs.getInt("customerid"));	
				return customer;
			}
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		return null;
	}  

	public int login(String email, String password)
    {
        String customer_login_query = "SELECT customerid, password FROM customers WHERE email = ?";

        try(PreparedStatement ps = con.prepareStatement(customer_login_query))
        {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            {
                if(rs.getString("password").equals(password))
                {
                    CUSTOMER_ID = rs.getInt("customerid");
                    return CUSTOMER_ID;
                }
            }
            rs.close();
        }
        catch(SQLException e) 
        {
            System.out.println(e.getMessage());
        }
        return -1;
    }

	public void logout()
    {
        try
        {
            con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}
