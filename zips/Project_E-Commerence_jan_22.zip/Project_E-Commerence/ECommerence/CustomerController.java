package ECommerence;

public class CustomerController 
{
    private CustomerDAO customerDAO;
    private CustomerView customerView;

    public CustomerController(CustomerDAO customerDAO, CustomerView customerView)
    {
        this.customerDAO = customerDAO;
        this.customerView = customerView;
    }

    public void signUp()
    {
        Customer customer = customerView.newCustomer();
        customerDAO.addCustomer(customer);
    }

    public int login()
    {
        String[] credentials = customerView.credentials();
        if(credentials != null)
        {
            return customerDAO.login(credentials[0], credentials[1]);
        }
        return -1;
    }

    public boolean logout()
    {
        customerDAO.logout();
        customerView.logout();
        return true;
    }

    public void getCustomerName()
    {
        String customerName = customerDAO.getCustomer().getFirstName();
        customerView.getCustomerName(customerName);
    }
}
