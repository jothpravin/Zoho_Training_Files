package ECommerence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MerchantDAO 
{
    static int MERCHANTID;
    static Connection con = ConnectionDB.getConnection();
    
    public void newMerchant(Merchant merchant)
    {
        String query = "INSERT INTO merchant (firstname, lastname, email, password, mobile_no, companyname, address, gst_no, pan_no) VALUES"+
                        "(?, ?, ?, ?, ?, ?, ?, ? ,?)";

        try(PreparedStatement ps = con.prepareStatement(query))
        {
            ps.setString(1, merchant.getFirstName());
            ps.setString(2, merchant.getLastName());
            ps.setString(3, merchant.getEmail());
            ps.setString(4, merchant.getPassword());
            ps.setLong(5, merchant.getMobile_no());
            ps.setString(6, merchant.getCompanyName());
            ps.setString(7, merchant.getAddress());
            ps.setString(8, merchant.getGST_no());
            ps.setString(9, merchant.getPAN_no());

            int row = ps.executeUpdate();
            if(row > 0)
            {
                System.out.println("Successfully New Merchant Account was Created...!");   
            }
        }
        catch(SQLException e)
        {
            System.out.println(e.getMessage());
        }
    }

    public Merchant getMerchant()
    {
        String query = "SELECT * FROM merchant WHERE merchantid = ?";
        try(PreparedStatement ps = con.prepareStatement(query))
        {
            ps.setInt(1, MERCHANTID);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            {
                Merchant merchant = new Merchant(rs.getString("firstname"),
                                                rs.getString("lastname"), 
                                                rs.getString("email"), 
                                                rs.getString("password"), 
                                                rs.getLong("mobile_no"), 
                                                rs.getString("companyname"), 
                                                rs.getString("address"), 
                                                rs.getString("gst_no"), 
                                                rs.getString("pan_no")
                                                );
                merchant.setMerchantId(rs.getInt("merchantid"));
                merchant.setAmount(rs.getLong("amount"));
                return merchant;
            }
        }
        catch(SQLException e)
        {
            System.out.println(e.getMessage());
        }
        return null;
    }

    public int login(String email, String password)
    {
        String customer_login_query = "SELECT merchantid, password FROM merchant WHERE email = ?";

        try(PreparedStatement ps = con.prepareStatement(customer_login_query))
        {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if(rs.next())
            {
                if(rs.getString("password").equals(password))
                {
                    MERCHANTID = rs.getInt("merchantid");
                    return MERCHANTID;
                }
            }
            rs.close();
        }
        catch(SQLException e) 
        {
            System.out.println(e.getMessage());
        }
        return -1;
    }

    public void logout()
    {
        try
        {
            con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}
