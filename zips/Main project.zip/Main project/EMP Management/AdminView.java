package employeeManagement;

public class AdminView 
{
    public void AdminProcess()
    {
        int empOpt = 0;
        boolean signin = true; 
        EmployeeController emp = new EmployeeController();
        HRController hr = new HRController();
        AdminController admin = new AdminController();
        while(signin)
        {
            System.out.println("1. Add Employee \n2. Add Role \n3. Add Team \n4. Remove Employee \n5. Remove Role \n6. Remove Team");
            switch(empOpt)
            {
                case 1:
                    hr.addEmployee();
                case 2:
                    admin.addRole();
                case 3:
                    admin.addTeam();
                case 4:
                    hr.removeEmployee();
                case 5: 
                    admin.removeRole();
                case 6:
                    admin.removeTeam();
                default:
                    System.out.println("Select correct option...!");
            }
        }
         
    }       
}
