package employeeManagement;

import java.util.Scanner;

public class EmployeeManagementSystem 
{
    public static void main(String[] args) 
    {
        boolean flag = true;
        int userOpt;
        Scanner sc = new Scanner(System.in);
        String username = null;
        String password = null;
        Query query = new Query();
        AdminView admin = new AdminView();
        EmployeeView emp = new EmployeeView();
        HRView hr = new HRView();
        while(flag)
        {
            System.out.println("1. Admin \n2. Employee \3. Exit");
            userOpt = sc.nextInt();
            switch(userOpt)
            {
                case 1:
                    System.out.println("Enter username: ");
                    username = sc.next();
                    System.out.println("Enter Password: ");
                    password = sc.next();
                    if(query.authendicateAdmin(username, password))
                    {
                        admin.AdminProcess();
                    }
                    else
                    {
                        System.out.println("check username and password...!");
                    }
                case 2:
                    System.out.println("Enter Email: ");
                    username = sc.next();
                    System.out.println("Enter Password: ");
                    password = sc.next();
                    if(query.authendicate(username, password))
                    {
                        if(query.isHR(query.empid))
                        {
                            hr.hrProcess();
                        }
                        else
                        {
                            emp.employeeProcess(query.empid);
                        }
                    }
                case 3:
                    flag = !flag;
                    sc.close();

            
            }
        }
    }
}
