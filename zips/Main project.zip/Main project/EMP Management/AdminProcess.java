package employeeManagement;

interface AdminProcess 
{
    void addRole();
    void removeRole();
    void addTeam();
    void removeTeam();
}
