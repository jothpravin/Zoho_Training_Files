package employeeManagement;

public class AdminController implements AdminProcess
{
    Query query = new Query();
    public void addRole()
    {
        System.out.println("Enter the role ");
        String role = query.sc.nextLine();
        query.insertRole(role);
    }
    public void removeRole()
    {
        System.out.println("Enter the role ");
        String role = query.sc.nextLine();
        query.deleteRole(role);
    }
    public void addTeam()
    {
        System.out.println("Enter the team ");
        String team = query.sc.nextLine();
        query.insertTeam(team);
    }
    public void removeTeam()
    {
        System.out.println("Enter the team ");
        String team = query.sc.nextLine();
        query.deleteTeam(team);
    }
}
