package employeeManagement;

class Address
{
    private int door_no;
    private String street_name;
    private String city;
    private int postal_code;
    
    Address(int door_no, String street_name, String city, int postal_code)
    {
        this.door_no = door_no;
        this.street_name = street_name;
        this.city = city;
        this.postal_code = postal_code;
    }
    
    public String toString()
    {
        return door_no +", " + street_name +", "+ city + ", " + postal_code;
    }
}
