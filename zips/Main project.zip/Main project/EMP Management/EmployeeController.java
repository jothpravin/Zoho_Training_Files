package employeeManagement;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.text.SimpleDateFormat;  
import java.util.Date;  


class EmployeeController implements EmployeeProcess
{
    Validation val = new Validation();
    Query query = new Query();
    public void updateAddress(int empid)
    {
        String value = val.collectAddress().toString();
        query.updateEmplyeeDeatails(empid, "ADDRESS", value);
    }
    
    public void getEmployeeDetails(int empid)
    {
        LinkedHashMap map = query.getEmployeeinfo(empid);
        printEmployeeDetails(map);
    }

    public void printEmployeeDetails(LinkedHashMap map)//helps to print employee details
    {
        Set entry_set = map.entrySet();
        Iterator itr = entry_set.iterator();

        while(itr.hasNext())
        {
            Map.Entry entry = (Map.Entry)itr.next();
            System.out.println(entry.getKey() + " : " +entry.getValue());
        }
    }
    public void applyLeave(int empid)
    {
        Date from = val.validateDate();
        Date to = val.validateDate();
    }
    
    public void checkIn(int empid)
    {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
        java.util.Date date = new java.util.Date();  
        Date check_in = formatter.format(date); 
        insertAttendance(check_in, empid)
    }
    
    public void checkOut(int empid)
    {
    
    } 
}
