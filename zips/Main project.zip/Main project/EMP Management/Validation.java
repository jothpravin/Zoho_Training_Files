package employeeManagement;

import java.util.regex.Pattern;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.sql.Date;

class Validation 
{
    Scanner sc = new Scanner(System.in);
    public Date validateDate()
    {
        Date date = null;
        String d = sc.nextLine();
        Pattern p = Pattern.compile("\\d{4}-(?:0[1-9]|1[12])-(?:0[1-9]|[12][0-9]|3[01])");
        //Pattern p = Pattern.compile("(?:0[1-9]|[12][0-9]|3[01])/(?:0[1-9]|1[12])/\\d{4}");
        Matcher m = p.matcher(d);
        if(!m.find())
        {
            System.out.println("Enter valid date");
            date = validateDate();
        }
        
        date = Date.valueOf(d);
        return date;
    }
    
    public String validateMobileNo()
    {
        System.out.println("Enter Mobile number: ");
        String number = sc.nextLine();
        
        number = number.replaceAll("\\s", "");
        Pattern p = Pattern.compile("\\d{10}");
        Matcher m = p.matcher(number);
        if(!m.find())
        {
            System.out.println("Enter valid number");
            number = validateMobileNo();
        }
        
        return number;
    }
    
    public String validateAadhaarNo()
    {
        System.out.println("Enter aadhaar number: ");
        String number = sc.nextLine();
        
        number = number.replaceAll("\\s", "");
        Pattern p = Pattern.compile("\\d{12}");
        Matcher m = p.matcher(number);
        if(!m.find())
        {
            System.out.println("Enter valid number");
            number = validateAadhaarNo();
        }
        
        return number;
    }
    
    public Address collectAddress()
    {
        System.out.println("Enter door number: ");
        int door_no = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter street name: ");
        String street_name = sc.nextLine();
        System.out.println("Enter you city: ");
        String city = sc.nextLine();
        System.out.println("Enter postalcode: ");
        int postal_code = sc.nextInt();
        Address address = new Address(door_no, street_name, city, postal_code);
        return address;
    }
    
    public boolean maritalStatus()
    {
        System.out.println("Enter marital status of employee: married/unmarried");
        boolean status = sc.next().toLowerCase().charAt(0) == 'm' ? true:false;
        return status;
    }

    public String generateEmail(String name, String father_name)
    {
        String email = name+father_name +"@zoho.com";
        return email;
    }
}
