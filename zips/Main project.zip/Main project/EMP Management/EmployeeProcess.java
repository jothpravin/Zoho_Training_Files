package employeeManagement;

interface EmployeeProcess
{
    void updateAddress(int empid);
    void getEmployeeDetails(int empid);
    void applyLeave(int empid);
    void checkIn(int empid);
    void checkOut(int empid);
}
