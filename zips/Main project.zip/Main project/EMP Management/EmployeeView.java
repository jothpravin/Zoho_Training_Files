package employeeManagement;

public class EmployeeView 
{
    public void employeeProcess(int empid)
    {
        int empOpt = 0;
        boolean signin = true; 
        EmployeeController emp = new EmployeeController();
        while(signin)
        {
            System.out.println("1. Update address \n2. get Employee Details \n3. Apply leave \n4. List Check In \n5. Check Out");
            switch(empOpt)
            {
                case 1:
                    emp.updateAddress(empid);
                case 2:
                    emp.getEmployeeDetails(empid);
                case 3:
                    emp.applyLeave(empid);
                case 4:
                    emp.checkIn(empid);
                case 5: 
                    emp.checkOut(empid);
                default:
                    System.out.println("Select correct option...!");
            }
        }
         
    }   
}
