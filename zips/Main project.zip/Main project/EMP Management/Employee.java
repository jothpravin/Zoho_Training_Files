package employeeManagement;

import java.sql.Date;

class Employee
{
    String name = null;
    Date date_of_birth = null;
    int salary = 0;
    String mobile = null;
    String aadhaar = null;
    String email = null;
    String father_name = null;
    String mother_name = null;
    Date date_of_joining = null;
    boolean marital_status = false;
    String blood_group = null;
    int gender = 0;
    Address address = null;
    private String gender_show = null;
    
    Employee(String name, Date date_of_birth, int salary, String mobile, String aadhaar, String email, String father_name, String mother_name, Date  date_of_joining, boolean marital_status, String blood_group, int gender, Address address)
    {
        this.name = name;
        this.date_of_birth = date_of_birth;
        this.salary = salary;
        this.mobile = mobile;
        this.aadhaar = aadhaar;
        this.email = email;
        this.father_name = father_name;
        this.mother_name = mother_name;
        this.date_of_joining = date_of_joining;
        this.marital_status = marital_status;
        this.blood_group = blood_group;
        this.gender = gender;
        this.address = address;
    }

    private void selectGender()
    {
        if(gender == 1)
        {
            gender_show = "Male";
        }else if(gender == 2)
        {
            gender_show = "Female";
        }else if(gender == 3)
        {
            gender_show = "Others";
        }      
    }
    
    public String toString()
    {
        selectGender();
        return "Name: " + name + "\nDOB:" + date_of_birth + "\nMobile Number: " + mobile + "\nAadhaar Number: " + aadhaar + "\nEmail: " + email +"\nFather Name: " + father_name + "\nMother Name: " + mother_name + "\nDate of Joining: "+date_of_joining + "\nBlood Group: "+ blood_group +"\nGender: "+gender_show;
    }
    
}
