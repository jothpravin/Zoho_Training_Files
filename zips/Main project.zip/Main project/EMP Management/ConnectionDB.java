package employeeManagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.SQLException;

public class ConnectionDB 
{
    static ConnectionDB db = null;
    static Connection con = null;
    static Statement stm = null;
    private final String driver = "org.postgresql.Driver";
    private final String url = "jdbc:postgresql://localhost:5432/employeeManagement";
    private final String username = "postgres";
    private final String password  = "root";

    private ConnectionDB()
    {
    } 

    public static ConnectionDB getConnectionDB()
    {
        if(db == null)
        {
            db = new ConnectionDB();
        }
        
        if(con == null)
        {
            con = db.connect();
        }
        return db;
    }

    private Connection connect()
    {
        try{
            Class.forName(driver);
            con = DriverManager.getConnection(url, username, password);
            stm = con.createStatement();
            //method call for table creation
            createAdminTable();
            createGenderTable();
            createRolesTable();
            createTeamsTable();
            createEMPDetailsTable();
            createTeamEmployeeMappingTable();
            createRoleEmployeeMappingTable();
            createLoginTable();
            createAttendanceTable();
            leaveTable();
            createSalaryInfo();
        }
        catch(SQLException e )
        {
            e.printStackTrace();
        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return con;
    }
    
    /*private static void  createPersonalInfoTable() throws SQLException
    {
        String personal_info = "CREATE TABLE IF NOT EXISTS PERSONAL_INFO (PID SERIAL PRIMARY KEY, DOB DATE NOT NULL, MOBILENUMBER VARCHAR(10) NOT NULL, AADHAARNUMBER VARCHAR(12) NOT NULL, FATHERNAME VARCHAR(30), MOTHERNAME VARCHAR(30), MARITALSTATUS BOOLEAN,BLOODGROUP VARCHAR(10), GENDER INT NOT NULL, ADDRESS VARCHAR(200))";
        stm.executeUpdate(personal_info);
    }*/
    
    private static void createAdminTable() throws SQLException
    {
        String admin_table = "CREATE TABLE IF NOT EXISTS ADMIN (ID SERIAL PRIMARY KEY, USERNAME VARCHAR(10) UNIQUE, PASSWORD VARCHAR(20))";
        stm.executeUpdate(admin_table);
    }
    
    private static void createGenderTable() throws SQLException
    {
        String gender_table = "CREATE TABLE IF NOT EXISTS GENDER (ID SERIAL PRIMARY KEY, GENDER VARCHAR(15))";
        stm.executeUpdate(gender_table);
    }
    
    private static void createRolesTable() throws SQLException
    {
        String roles_table = "CREATE TABLE IF NOT EXISTS ROLES (ID SERIAL PRIMARY KEY, ROLE_NAME VARCHAR(50) NOT NULL UNIQUE)";
        stm.executeUpdate(roles_table);
    }
    

    private static void createTeamsTable() throws SQLException
    {
        String teams_table = "CREATE TABLE IF NOT EXISTS TEAMS (ID SERIAL PRIMARY KEY, TEAM_NAME VARCHAR(50) NOT NULL UNIQUE)";
        stm.executeUpdate(teams_table);
    }
    
    private static void createEMPDetailsTable() throws SQLException
    {
        String emp_details_table = "CREATE TABLE IF NOT EXISTS EMP_DETAILS (ID SERIAL PRIMARY KEY, NAME VARCHAR(30), EMAIL VARCHAR(100) NOT NULL UNIQUE,DOB DATE NOT NULL, MOBILENUMBER BIGINT NOT NULL, AADHAARNUMBER BIGINT NOT NULL, FATHERNAME VARCHAR(30), MOTHERNAME VARCHAR(30), DATEOFJOINING DATE,MARITALSTATUS BOOLEAN,BLOODGROUP VARCHAR(10), GENDER INT REFERENCES GENDER(ID), ADDRESS TEXT, STATUS BOOLEAN DEFAULT '1')";
        stm.executeUpdate(emp_details_table	);
    }

    private static void createTeamEmployeeMappingTable() throws SQLException
    {
        String team_employee_mapping_table = "CREATE TABLE IF NOT EXISTS TEAMEMPLOYEEMAPPING (ID SERIAL PRIMARY KEY, EMPID INT REFERENCES EMP_DETAILS(ID), TEAMID INT REFERENCES TEAMS(ID))";
        stm.executeUpdate(team_employee_mapping_table);
    }
    
    private static void createRoleEmployeeMappingTable() throws SQLException
    {
        String role_employee_mapping_table = "CREATE TABLE IF NOT EXISTS ROLEEMPLOYEEMAPPING (ID SERIAL PRIMARY KEY, EMPID INT REFERENCES EMP_DETAILS(ID), ROLEID INT REFERENCES ROLES(ID))";
        stm.executeUpdate(role_employee_mapping_table);
    }
	
    private static void createLoginTable() throws SQLException
    {
        String login_table = "CREATE TABLE IF NOT EXISTS LOGIN (ID SERIAL PRIMARY KEY, USERNAME VARCHAR(50) UNIQUE, PASSWORD VARCHAR(15), EMPID INT REFERENCES EMP_DETAILS(ID))";
        stm.executeUpdate(login_table);
    }
    
    private static void createAttendanceTable() throws SQLException
    {
        String attendance_table = "CREATE TABLE IF NOT EXISTS ATTENDANCE (ID SERIAL PRIMARY KEY, CHECK_IN TIMESTAMP, CHECK_OUT TIMESTAMP, EMPID INT REFERENCES EMP_DETAILS(ID))";
        stm.executeUpdate(attendance_table);
    }
    
/*    private static void createRequestTable() throws SQLException
    {
        String request_table = "CREATE TABLE IF NOT EXISTS REQUEST (ID SERIAL PRIMARY KEY, TYPE VARCHAR(30), EMP_ID INT, CONSTRAINT FK_EMP_ID_REQUEST FOREIGN KEY(EMP_ID) REFERENCES EMP_DETAILS(EMP_ID), STATUS VARCHAR(30) DEFAULT 'PENDING')";
        stm.executeUpdate(request_table);
    }*/
    
    private static void leaveTable() throws SQLException
    {
        String leave_table = "CREATE TABLE IF NOT EXISTS LEAVE (ID SERIAL PRIMARY KEY, EMPID INT REFERENCES EMP_DETAILS(ID), FROML DATE, TOL DATE, REASON VARCHAR(100), CREATED_AT DATE, STATUS VARCHAR DEFAULT 'PENDING')";
        stm.executeUpdate(leave_table);
    }

    public static void createSalaryInfo() throws SQLException 
    {
        String Salary_info = "CREATE TABLE SALARYINFO (ID SERIAL PRIMARY KEY, EMPID INT REFERENCES EMP_DETAILS(ID), SALARY INT, YEAR INT, COMMENTS TEXT)";
        stm.executeUpdate(Salary_info);
    }
/*    
    private static void assertTable() throws SQLException
    {
        String assert_table = "CREATE TABLE IF NOT EXISTS LEAVE (ID SERIAL PRIMARY KEY, REQUEST_ID INT, CONSTRAINT FK_REQUEST_ID_LEAVE FOREIGN KEY(REQUEST_ID) REFERENCES REQUEST(ID), LEAVE_START DATE, LEAVE_END DATE, REASON VARCHAR(100), CREATED_AT DATE, STATUS VARCHAR DEFAULT 'PENDING')";
        stm.executeUpdate(leave_table);
    }
    
    private static void serviceTable() throws SQLException
    {
        String service_table = "CREATE TABLE IF NOT EXISTS SERVICE (ID SERIAL PRIMARY KEY, REQUEST_ID INT, CONSTRAINT FK_REQUEST_ID_ASSERT FOREIGN KEY(REQUEST_ID) REFERENCES REQUEST(ID), TYPE VARCHAR(30), CREATED_AT DATE, DESCRIPTION VARCHAR(100), STATUS VARCHAR DEFAULT 'PENDING')";
        stm.executeUpdate(service_table);
    }*/
}
