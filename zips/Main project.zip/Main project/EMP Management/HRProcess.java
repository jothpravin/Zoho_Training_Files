package employeeManagement;

interface HRProcess
{
    void addEmployee();//hr
    void updateEmployee();//hr
    void removeEmployee();//hr
    void viewEmployees();
    void viewEmployeeBasedonRole();
    void viewEmployeeBasedonTeam();
    void getEmployeeDetails();//hr and employee
    void approveLeave();//hr
    void check_in();//employee
    void check_out();//employee
}
