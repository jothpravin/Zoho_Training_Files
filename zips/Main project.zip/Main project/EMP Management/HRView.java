package employeeManagement;

public class HRView 
{
    HRController hr = new HRController();
    public void hrProcess()
    {
        int hrOpt = 0;
        boolean signin = true; 
        while(signin)
        {
            System.out.println("1. Add Employee \n2. Update Employee \n3. Remove Employee \n4. List Employee \n5. Get Employee Details \n6. Update salary \n7. Approve Leave");
            switch(hrOpt)
            {
                case 1:
                    hr.addEmployee();
                case 2:
                    hr.updateEmployee();
                case 3:
                    hr.removeEmployee();
                case 4:
                    hr.listEmployee();
                case 5: 
                    hr.getEmployeeDetails();
                case 6:
                    hr.updateSalary();
                case 7:
                    hr.approveLeave();
            }
        }
         
    }
    
}
