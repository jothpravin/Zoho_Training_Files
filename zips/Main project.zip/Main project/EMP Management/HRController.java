package employeeManagement;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.sql.Date;
import java.time.Year;
import java.sql.Connection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;


class HRController
{
    Scanner sc = new Scanner(System.in);
    Query query = new Query();  
    Connection con = query.con;
    Validation val = new Validation();
    int empid = 0;
    public void addEmployee()
    {
        System.out.println("Enter employee's name: ");
        String name = sc.nextLine();
        System.out.println("Enter employee's salary: ");
        int salary = sc.nextInt();
        System.out.println("Enter your date of birth: yyyy-mm-dd");
        Date dob = val.validateDate();//get the date from user and validate the date
        String mobile = val.validateMobileNo();//validating the mobile number
        String aadhaar = val.validateAadhaarNo();//validate the aadhaar number
        System.out.println("Enter employee's father name: ");
        String father_name = sc.nextLine();
        System.out.println("Enter employee's mother name: ");
        String mother_name = sc.nextLine();
        System.out.println("Enter the date of joining: yyyy-mm-dd");
        Date date_of_joining = val.validateDate();
        boolean marital_status = val.maritalStatus();
        System.out.println("Enter employee's Blood group: ");
        String blood_group = sc.next().toUpperCase();
        String email = val.generateEmail(name, father_name);
        String password = sc.next();
        int gender = assignGender();//assigning gender
        Address address = val.collectAddress();
        Employee emp = new Employee(name, dob, salary, mobile, aadhaar, email, father_name, mother_name, date_of_joining, marital_status, blood_group, gender, address);
        //String name, Date date_of_birth, int salary, String mobile, String aadhaar, String email, String father_name, String mother_name, boolean marital_status, String blood_group, String gender, Address address
        //"CREATE TABLE IF NOT EXISTS EMP_DETAILS (ID SERIAL PRIMARY KEY, NAME VARCHAR(30), EMAIL VARCHAR(100) NOT NULL UNIQUE,DOB DATE NOT NULL, MOBILENUMBER BIGINT NOT NULL, AADHAARNUMBER BIGINT NOT NULL, FATHERNAME VARCHAR(30), MOTHERNAME VARCHAR(30), DATEOFJOINING DATE,MARITALSTATUS BOOLEAN,BLOODGROUP VARCHAR(10), GENDER INT REFERENCES GENDER(ID), ADDRESS TEXT, STATUS BOOLEAN DEFAULT '1')"
        
        long mobile_number = Long.parseLong(mobile); //here i am parsing mobile number and aadhaar number from string to long to store data in database
        long aadhaar_number = Long.parseLong(aadhaar);

        empid = query.insertEmployeeDetails(name, email, dob, mobile_number, aadhaar_number, father_name, mother_name, date_of_joining, marital_status, blood_group, gender, address.toString());
        query.insertLoginDetails(email, password, empid);

        assignRole(empid);
        assignTeam(empid);
        insertSalary(empid, salary);
    }
    public void updateEmployee()
    {
        System.out.println("1. Name \n2. Email \n3. Date of Birth \n4. Mobile Number \n5. Aadhaar Number \n6. FatherName \n7. Mother Name \n8. Date of Joining \n9. Marital Status \n10. Blood Group \n11. Gender \n12. Address \n13. Active Status");
        int userOpt = sc.nextInt();
        empid = collectEMPID();
        sc.nextLine();
        boolean flag = query.isEmployeeExist(empid);
        if(flag)
        {
            switch(userOpt)
            {
                case 1:
                    System.out.println("Enter the Name: ");
                    String name = sc.nextLine();
                    query.updateEmplyeeDeatails(empid, "NAME", name);
                    break;
                case 2:
                    System.out.println("Enter the email: ");
                    String email = sc.nextLine();
                    query.updateEmplyeeDeatails(empid, "EMAIL", email);
                    break;
                case 3:
                    System.out.println("Enter the Date of Birth: ");
                    Date date_of_birth =val.validateDate();
                    query.updateEmplyeeDeatails(empid, "DOB", date_of_birth);
                    break;
                case 4:
                    String mobile = val.validateMobileNo();
                    query.updateEmplyeeDeatails(empid, "MOBILENUMBER", Long.parseLong(mobile));
                    break;
                case 5:
                    String aadhaar = val.validateAadhaarNo();
                    query.updateEmplyeeDeatails(empid, "AADHAARNUMBER", aadhaar);
                    break;
                case 6:
                    System.out.println("Enter the Father Name: ");
                    String father_name = sc.nextLine();
                    query.updateEmplyeeDeatails(empid, "FATHERNAME", father_name);
                    break;
                case 7:
                    System.out.println("Enter the Mother Name: ");
                    String Mother_name = sc.nextLine();
                    query.updateEmplyeeDeatails(empid, "MOTHERNAME", Mother_name);
                    break;
                case 8:
                    System.out.println("Enter the Date of joining: ");
                    Date doj = val.validateDate();
                    query.updateEmplyeeDeatails(empid, "DATEOFJOINING", doj);
                    break;
                case 9:
                    System.out.println("Select Marital Status: \n1. Married \n2. Unmarried");
                    int opt = sc.nextInt();
                    Boolean marital_status = false;
                        switch(opt)
                        {
                            case 1:
                                marital_status = true;
                                break;
                            case 2:
                                marital_status = false;
                                break;
                            default:
                                System.out.println("Select correct option");
                        }
                    query.updateEmplyeeDeatails(empid, "MARITALSTATUS", marital_status);
                    break;
                case 10:
                    System.out.println("Enter the Blood Group ");
                    String blood_group = sc.next().toUpperCase();
                    query.updateEmplyeeDeatails(empid, "BLOODGROUP", blood_group);
                    break;
                case 11:
                    int gender = assignGender();
                    query.updateEmplyeeDeatails(empid, "GENDER", gender);
                    break;
                case 12:
                    String address = val.collectAddress().toString();
                    query.updateEmplyeeDeatails(empid, "ADDRESS", address);
                    break;
                case 13:
                    System.out.println("Select Marital Status: \n1. active \n2. deactive");
                    int option = sc.nextInt();
                    Boolean active_status = true;
                        switch(option)
                        {
                            case 1:
                                active_status = true;
                                break;
                            case 2:
                                active_status = false;
                                break;
                            default:
                                System.out.println("Select correct option");
                        }
                    query.updateEmplyeeDeatails(empid, "STATUS", active_status);

                default :
                    System.out.println("Select oprtion properly");
            }
        }
        else
        {
            System.out.println("There is no employee associated with give employee id....!");
        }
    }

    public void listEmployee()
    {
        System.out.println("List employee:  \n1. Total Employee List \n2. List Employee Based on Team \n3. List Employee Based on Role");
        int userOpt = sc.nextInt();
        switch(userOpt)
        {
            case 1://need to complete
                query.listEmployee();
                break;
            case 2:
                System.out.println("Enter Team Id: ");
                int teamid = sc.nextInt();
                if(query.isTeamExist(teamid))
                {
                    query.listEmployee(teamid, "team");
                }
                else
                {
                    System.out.println("Team ID doesn't exist...!");
                }
                break;
            case 3:
                System.out.println("Enter Role Id: ");
                int roleid = sc.nextInt();
                if(query.isRoleExist(roleid))
                {
                    query.listEmployee(roleid, "role");
                }
                else
                {
                    System.out.println("Role ID doesn't exist...!");
                }
                break;
        }
    }
    
    public void removeEmployee()
    {
        empid = collectEMPID();
        if(query.isActive(empid))
        {
            query.removeEmployee(empid);
            System.out.println("Successfully removed....!");
        }
        else
        {
            System.out.println("there is no employee associated with given employee id....!");
        }
        
    }
    
    public void getEmployeeDetails()
    {
        LinkedHashMap employee = null;
        empid = collectEMPID();
        if(query.isActive(empid))
        {
             employee = query.getEmployeeinfo(empid);
        }
        else
        {
            System.out.println("There is no employee associated with given emp id...!");
        }
        printEmployeeDetails(employee);
    }

    public void printEmployeeDetails(LinkedHashMap map)
    {
        Set entry_set = map.entrySet();
        Iterator itr = entry_set.iterator();

        while(itr.hasNext())
        {
            Map.Entry entry = (Map.Entry)itr.next();
            System.out.println(entry.getKey() + " : " +entry.getValue());
        }
    }
    public void insertSalary(int empid, int salary)
    {
        //INSERT INTO SALARYINFO (EMPID, SALARY, YEAR, COMMENTS) VALUES (?, ?, ?, ?)
        int year = Year.now().getValue();

        System.out.println("Enter comments: ");
        String comments = sc.nextLine();

        query.insertSalaryDetails(empid, salary, year, comments);
    }
    public void updateSalary()//updatesalary
    {
        empid = collectEMPID();
        if(query.isEmployeeExist(empid))
        {
            System.out.println("Enter the salary: ");
            int salary = sc.nextInt();
            insertSalary(empid, salary);
        }
        else
        {
            System.out.println("Check the employee id...!");
        }
    }
    
    public void approveLeave()
    {
        empid = collectEMPID();
        query.approveLeave(empid);
    }
    
    public void check_in()
    {
    
    }
    
    public void check_out()
    {
    
    }

    public int assignGender()
    {
        viewGender();
        System.out.println("Select gender based on id: ");
        int gender = sc.nextInt();
        return gender;
    }

    public void assignRole(int emp_id)
    {
        viewRoles();
        System.out.println("Select role based on id: ");
        int role_id = sc.nextInt();
        query.assignEmployeeRole(emp_id, role_id);
    }

    public void assignTeam(int emp_id)
    {
        viewTeams();
        System.out.println("Select team based on id: ");
        int team_id = sc.nextInt();
        query.assignEmployeeRole(emp_id, team_id);
    }

    public void viewTeams()
    {
        ArrayList<String> teams = query.getTeams();
        Iterator<String> itr = teams.iterator();
        System.out.println("ID     TEAM");
        while(itr.hasNext())
        {
            System.out.println((String)itr.next());
        }
    }

    public void viewRoles()
    {
       ArrayList<String> roles =  query.getRoles();
       Iterator<String> itr = roles.iterator();
       System.out.println("ID     ROLE");
       while(itr.hasNext())
        {
            System.out.println((String)itr.next());
        }
    }

    public void viewGender()
    {
        ArrayList<String> genders = query.getGender();
        Iterator<String> itr = genders.iterator();
       System.out.println("ID     GENDER");
       while(itr.hasNext())
        {
            System.out.println((String)itr.next());
        }
    }

    public int collectEMPID()//collect emp id from hr
    {
        System.out.println("Enter Emp Id: ");
        empid = sc.nextInt();
        return empid;
    }
    
}
