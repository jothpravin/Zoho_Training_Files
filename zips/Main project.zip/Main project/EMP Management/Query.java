package employeeManagement;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Scanner;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Date;


class Query
{
    static ConnectionDB db = ConnectionDB.getConnectionDB(); //here i am getting ConnectionDB object  
    Connection con = ConnectionDB.con;
    PreparedStatement pstm = null;
    Statement stm = ConnectionDB.stm;
    ResultSet rs = null;
    ArrayList<String> list = null;
    Scanner sc = new Scanner(System.in);
    int empid = 0;

    public boolean authendicate(String email, String password)
    {
        String authendicate = "SELECT(CASE WHEN PASSWORD = "+ password +" THEN 'true' ELSE 'false' END) AS login_val FROM LOGIN WHERE USERNAME =" + email;
        boolean flag = false;
        try
        {
            rs = stm.executeQuery(authendicate);
            while(rs.next())
            {
                flag = rs.getBoolean("login_val");
                empid = rs.getInt("EMPID");
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        return flag && isActive(empid);
    }

    public boolean isActive(int empid)
    {
        String check_status = "SELECT (CASE WHEN " + empid + " THEN 'true' ELASE 'false' END) AS is_active FROM EMP_DETAILS WHERE STATUS = true";
        boolean is_active = false;
        try
        {
            rs = stm.executeQuery(check_status);
            rs.next();
            is_active = rs.getBoolean("is_active");
        }
        catch(SQLException e)
        {
            e.printStackTrace();
            System.out.println("your account not in the active status please contact hr");
        }

        return is_active;
    }

    public boolean isEmployeeExist(int empid) // same method as isActive
    {
        boolean flag = false;
        String is_emplyee_exist = "SELECT(CASE WHEN " + empid + " THEN 'true' ELSE 'false' END) AS isExist FROM EMP_DETAILS WHERE STATUS = true";
        try
        {
            rs = stm.executeQuery(is_emplyee_exist);
            rs.next();
            flag = rs.getBoolean("isExist");
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return flag;
    }

    public boolean isHR(int empid)
    {
        boolean is_hr = false;
        String hr = "SELECT ROLE_NAME FROM ROLES INNER JOIN ROLEEMPLOYEEMAPPING ON ROLEEMPLOYEEMAPPING.ROLEID = ROLES.ID INNER JOIN EMP_DETAILS ON EMP_DETAILS.ID = ROLEEMPLOYEEMAPPING.EMPID WHERE EMP_DETAILS.ID = " + empid;
        String role = null;
        try
        {
            rs = stm.executeQuery(hr);
            while(rs.next())
            {
                role = rs.getString("ROLE_NAME");
            }

            if(role.toLowerCase().equals("hr"))
            {
                is_hr = true;
            }
        }
        catch(SQLException | NullPointerException e)
        {
            e.printStackTrace();
        }
        return is_hr;
    }

    public int insertEmployeeDetails(String name, String email, Date dob, long mobile, long aadhaar, String father_name, String mother_name, Date doj, boolean marital_status, String blood_group, int gender, String address)
    {
        //CREATE TABLE IF NOT EXISTS EMP_DETAILS (ID SERIAL PRIMARY KEY, NAME VARCHAR(30), EMAIL VARCHAR(100) NOT NULL UNIQUE,DOB DATE NOT NULL, MOBILENUMBER BIGINT NOT NULL, AADHAARNUMBER BIGINT NOT NULL, FATHERNAME VARCHAR(30), MOTHERNAME VARCHAR(30), DATEOFJOINING DATE,MARITALSTATUS BOOLEAN,BLOODGROUP VARCHAR(10), GENDER INT REFERENCES GENDER(ID), ADDRESS TEXT, STATUS BOOLEAN DEFAULT '1')   
        String personal_details = "INSERT INTO EMP_DETAILS (NAME, EMAIL, DOB, MOBILE_NUMBER, AADHAAR_NUMBER, FATHER_NAME, MOTHER_NAME, DATEOFJOINING, MARITAL_STATUS, BLOOD_GROUP, GENDER, ADDRESS) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING ID";
        int emp_id = 0;
        try
        {
            pstm = con.prepareStatement(personal_details);
            pstm.setString(1, name);
            pstm.setString(2, email);
            pstm.setDate(3, dob);
            pstm.setLong(4, mobile);
            pstm.setLong(5, aadhaar);
            pstm.setString(6, father_name);
            pstm.setString(7, mother_name);
            pstm.setDate(8, doj);
            pstm.setBoolean(9, marital_status);
            pstm.setString(10, blood_group);
            pstm.setInt(11, gender);
            pstm.setString(12, address);
            rs = pstm.executeQuery();
            rs.next();
            emp_id =  rs.getInt("ID");
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return emp_id;
    }
    
    public void createAdmin(String username, String password)
    {
        //"CREATE TABLE IF NOT EXISTS ADMIN (ID SERIAL PRIMARY KEY, USERNAME VARCHAR(10) UNIQUE, PASSWORD VARCHAR(10))"
        String create_admin = "INSERT INTO ADMIN (USERNAME, PASSWORD) VALUES(?, ?)";
        try
        {
            pstm = con.prepareStatement(create_admin);
            pstm.setString(1, username);
            pstm.setString(2, password);
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        
    }

    public boolean checkAdmin()
    {
        String check_admin = "SELECT COUNT(*) FROM ADMIN";
        boolean flag = false;
        try
        {
            rs = stm.executeQuery(check_admin);
            flag = rs.next();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return flag;
    }

    public boolean authendicateAdmin(String username, String password)
    {
        String authendicate_admin = "SELECT(CASE WHEN PASSWORD = "+ password +" THEN 'true' ELSE 'false' END) AS login_val FROM ADMIN WHERE USERNAME =" + username;
        boolean flag = false;
        try
        {
            rs = stm.executeQuery(authendicate_admin);
            while(rs.next())
            {
                flag = rs.getBoolean("login_val");
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return flag;
    }

    public void insertLoginDetails(String username, String password, int empid)
    {
        String insert_login_details = "INSERT INTO LOGIN (USERNAME, PASSWORD, EMPID) VALUES (?, ?, ?)";
        try
        {
            pstm = con.prepareStatement(insert_login_details);
            pstm.setString(1, username);
            pstm.setString(2, password);
            pstm.setInt(3, empid);
            pstm.executeUpdate();
        } 
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public void updateEmplyeeDeatails(int empid, String columnName, Date value)
    {
        
        String update_employee_details = "UPDATE EMP_DETAILS SET ? = ? WHERE ID = ?";
        try
        {
            pstm = con.prepareStatement(update_employee_details);
            pstm.setString(1, columnName);
            pstm.setDate(2, value);
            pstm.setInt(3, empid);

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        System.out.println("Successfully Updated....!");
    }

    public void updateEmplyeeDeatails(int empid, String columnName, long value)
    {
        
        String update_employee_details = "UPDATE EMP_DETAILS SET ? = ? WHERE ID = ?";
        try
        {
            pstm = con.prepareStatement(update_employee_details);
            pstm.setString(1, columnName);
            pstm.setLong(2, value);
            pstm.setInt(3, empid);

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        System.out.println("Successfully Updated....!");
    }

    public void updateEmplyeeDeatails(int empid, String columnName, String value)
    {
        
        String update_employee_details = "UPDATE EMP_DETAILS SET ? = ? WHERE ID = ?";
        try
        {
            pstm = con.prepareStatement(update_employee_details);
            pstm.setString(1, columnName);
            pstm.setString(2, value);
            pstm.setInt(3, empid);

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        System.out.println("Successfully Updated....!");
    }

    public void updateEmplyeeDeatails(int empid, String columnName, Boolean value)
    {
        
        String update_employee_details = "UPDATE EMP_DETAILS SET ? = ? WHERE ID = ?";
        try
        {
            pstm = con.prepareStatement(update_employee_details);
            pstm.setString(1, columnName);
            pstm.setBoolean(2, value);
            pstm.setInt(3, empid);

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        System.out.println("Successfully Updated....!");
    }

    public void removeEmployee(int empid)
    {
        String update_status = "UPDATE EMP_DETAILS SET STATUS = false WHERE ID = ?";
        try
        {
            pstm = con.prepareStatement(update_status);
            pstm.setInt(1, empid);
            pstm.executeUpdate();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public void listEmployee(int id, String type)
    {
        String list_employee = null;
        if(type.equals("team"))
        {
            list_employee = "SELECT * FROM EMP_DETAILS INNER JOIN TEAMEMPLOYEEMAPPING ON TEAMEMPLOYEEMAPPING.EMPID = EMP_DETAILS.ID INNER JOIN TEAMS ON TEAMS.ID = TEAMEMPLOYEEMAPPING.TEAMID WHERE TEAMID = ?";
        }
        else
        {
            list_employee = "SELECT * FROM EMP_DETAILS INNER JOIN ROLEEMPLOYEEMAPPING ON ROLEEMPLOYEEMAPPING.EMPID = EMP_DETAILS.ID INNER JOIN ROLES ON ROLES.ID = ROLEEMPLOYEEMAPPING.ROLEID WHERE ROLEID = ?";
        }
        try
        {
            pstm = con.prepareStatement(list_employee);
            pstm.setInt(1, id);
            rs = pstm.executeQuery();
            printEmployeeList(rs);
        } 
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public void listEmployee()
    {
        String list_employee = "SELECT * FROM EMP_DETAILS";
        try
        {
            rs = stm.executeQuery(list_employee);
            printEmployeeList(rs);
        } 
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public LinkedHashMap getEmployeeinfo(int empid)
    {
        LinkedHashMap map = new LinkedHashMap();

        String get_employee_info = "SELECT * FROM EMP_DETAILS WHERE ID =" + empid;
        try
        {
            rs = stm.executeQuery(get_employee_info);
            //CREATE TABLE IF NOT EXISTS EMP_DETAILS (ID SERIAL PRIMARY KEY, NAME VARCHAR(30), EMAIL VARCHAR(100) NOT NULL UNIQUE,DOB DATE NOT NULL, MOBILENUMBER BIGINT NOT NULL, AADHAARNUMBER BIGINT NOT NULL, FATHERNAME VARCHAR(30), MOTHERNAME VARCHAR(30), DATEOFJOINING DATE,MARITALSTATUS BOOLEAN,BLOODGROUP VARCHAR(10), GENDER INT REFERENCES GENDER(ID), ADDRESS TEXT, STATUS BOOLEAN DEFAULT '1')   
            rs.next();
            map.put("Name", rs.getString("NAME"));
            map.put("Email", rs.getString("EMAIL"));
            map.put("Date of Birth", rs.getDate("DOB"));
            map.put("Mobile Number", rs.getLong("MOBILENUMBER"));
            map.put("Aadhaar Number", rs.getLong("AADHAARNUMBER"));
            map.put("Date of Joing", rs.getDate("DATEOFJOINING"));
            map.put("Father Name", rs.getString("FATHERNAME"));
            map.put("Mother Name", rs.getString("MOTHERNAME"));
            map.put("Blood Group", rs.getString("BLOODGROUP"));
            String gender = null;
            int gender_type = rs.getInt("GENDER");
            if(gender_type == 1)
            {
                gender = "Male";
            }
            else if(gender_type == 2)
            {
                gender = "Female";
            }
            else
            {
                gender = "Others";
            }
            map.put("Address", gender);
            map.put("Address", rs.getString("ADDRESS"));
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        return map;
    }

    public void insertSalaryDetails(int empid, int salary, int year, String comments)
    {
        String insert_salary_details = "INSERT INTO SALARYINFO (EMPID, SALARY, YEAR, COMMENTS) VALUES (?, ?, ?, ?)";

        try
        {
            pstm = con.prepareStatement(insert_salary_details);
            pstm.setInt(1, empid);
            pstm.setInt(2, salary);
            pstm.setInt(3, year);
            pstm.setString(4, comments);
            pstm.executeUpdate();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public void insertIntoLeave(int empid, Date from, Date to, String reason)
    {
        //CREATE TABLE IF NOT EXISTS LEAVE (ID SERIAL PRIMARY KEY, EMPID INT REFERENCES EMP_DETAILS(ID), FROML DATE, TOL DATE, REASON VARCHAR(100), CREATED_AT DATE, STATUS VARCHAR DEFAULT 'PENDING')

        String insert_leave = "INSERT INTO LEAVE (EMPID, FROML, TOL, REASON CREATED_AT) VALUES ()";
    }

    public void approveLeave(int empid)
    {
        String approve_leave = "UPDATE LEAVE SET STATUS = APPROVED WHERE EMPID =" + empid;
        try
        {
            stm.executeUpdate(approve_leave);
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public void insertRole(String role)
    {
        String insert_role = "INSERT INTO ROLES (ROLE_NAME) VALUES(?)";
        try
        {
            pstm = con.prepareStatement(insert_role);
            pstm.setString(1, role);
            pstm.executeUpdate();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public void deleteRole(String role)
    {
        String delete_role = "DELETE FROM ROLES WHERE ROLE_NAME = ?";
        try
        {
            pstm = con.prepareStatement(delete_role);
            pstm.setString(1, role);
            pstm.executeUpdate();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public void insertTeam(String team)
    {
        String insert_team = "INSERT INTO TEAMS (TEAM_NAME) VALUES(?)";
        try
        {
            pstm = con.prepareStatement(insert_team);
            pstm.setString(1, team);
            pstm.executeUpdate();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    public void deleteTeam(String team)
    {
        String delete_team = "DELETE FROM TEAMS WHERE TEAM_NAME = ?";
        try
        {
            pstm = con.prepareStatement(delete_team);
            pstm.setString(1, team);
            pstm.executeUpdate();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public int insertAttendance(Timestamp check_in, int empid)//check in 
    {
        //CREATE TABLE IF NOT EXISTS ATTENDANCE (ID SERIAL PRIMARY KEY, CHECK_IN TIMESTAMP, CHECK_OUT TIMESTAMP, EMPID INT REFERENCES EMP_DETAILS(ID))
        String insert_attendance = "INSERT INTO ATTENDANCE(CHECK_IN, EMPID) VALUES (?, ?) RETURNING ID";
        try
        {
            pstm = con.prepareStatement(insert_attendance);
            pstm.setTimestamp(1, check_in);
            pstm.setInt(2, empid);
            pstm.executeUpdate(); 
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public boolean isTeamExist(int teamid)
    {
        boolean exist = false;
        String is_team_exist = "SELECT * FROM TEAMS";
        try
        {
            rs = stm.executeQuery(is_team_exist);
            while(rs.next())
            {
                if(teamid == rs.getInt("ID"))
                {
                    exist = true;
                    break;
                }
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return exist;
    }

    public boolean isRoleExist(int roleid)
    {
        boolean exist = false;
        String is_role_exist = "SELECT * FROM ROLES";
        try
        {
            rs = stm.executeQuery(is_role_exist);
            while(rs.next())
            {
                if(roleid == rs.getInt("ID"))
                {
                    exist = true;
                    break;
                }
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        return exist;
    }

    public void printEmployeeList(ResultSet rs)
    {
        try
        {
            String name = null;
            String email = null;
            long mobile = 0;
            Date doj = null;
            int Gender_type = 0;
            String gender = null;
            String employee_detail = null;
            System.out.println("Name          Email          Mobile          Date of Joining         Gender");
            while(rs.next())
            {
                //CREATE TABLE IF NOT EXISTS EMP_DETAILS (ID SERIAL PRIMARY KEY, NAME VARCHAR(30), EMAIL VARCHAR(100) NOT NULL UNIQUE,DOB DATE NOT NULL, MOBILENUMBER BIGINT NOT NULL, AADHAARNUMBER BIGINT NOT NULL, FATHERNAME VARCHAR(30), MOTHERNAME VARCHAR(30), DATEOFJOINING DATE,MARITALSTATUS BOOLEAN,BLOODGROUP VARCHAR(10), GENDER INT REFERENCES GENDER(ID), ADDRESS TEXT, STATUS BOOLEAN DEFAULT '1')   
                name = rs.getString("NAME");
                email = rs.getString("EMAIL");
                mobile = rs.getLong("MOBILENUMBER");
                doj = rs.getDate("DATEOFJOINING");
                Gender_type = rs.getInt("GENDER");
                if(Gender_type == 1)
                {
                    gender = "Male";
                }
                else if (Gender_type == 2)
                {
                    gender = "Female";
                }
                else if(Gender_type == 3)
                {
                    gender = "Others";
                }
                employee_detail = String.format("%10s %10s %10s %10s %10s ", name, email, mobile, doj, gender);
                System.out.println(employee_detail);
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public ArrayList<String> getTeams()
    {
        String get_teams = "SELECT * FROM TEAMS";
        list = new ArrayList<>(); 
        String team = "";
        try
        {
            rs = stm.executeQuery(get_teams);
            while(rs.next())
            {
                team = rs.getInt("ID") + "    " + rs.getString("TEAM_NAME"); 
                list.add(team);
                team = "";
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        return list;
    }

    public ArrayList<String> getRoles()
    {
        String get_roles = "SELECT * FROM ROLES";
        list = new ArrayList<>(); 
        String role = "";
        try
        {
            rs = stm.executeQuery(get_roles);
            while(rs.next())
            {
                role = rs.getInt("ID") + "    " + rs.getString("ROLE_NAME"); 
                list.add(role);
                role = "";
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        return list;
    }

    public void assignEmployeeRole(int emp_id, int role_id)
    {
        String assign_role = "INSERT INTO ROLEEMPLOYEEMAPPING (EMPID, ROLEID) VALUES (?, ?)";
        try
        {
            pstm = con.prepareStatement(assign_role);
            pstm.setInt(1, emp_id);
            pstm.setInt(2, role_id);
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public void assignEmployeeTeam(int emp_id, int team_id)
    {
        String assign_team = "INSERT INTO TEAMEMPLOYEEMAPPING (EMPID, TEAMID) VALUES (?, ?)";
        try
        {
            pstm = con.prepareStatement(assign_team);
            pstm.setInt(1, emp_id);
            pstm.setInt(2, team_id);
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public ArrayList<String> getGender()
    {
        String get_gender = "SELECT * FROM GENDER";
        list = new ArrayList<>(); 
        String gender = "";
        try
        {
            rs = stm.executeQuery(get_gender);
            while(rs.next())
            {
                gender = rs.getInt("ID") + "    " + rs.getString("GENDER"); 
                list.add(gender);
                gender = "";
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        return list;
    }
}
