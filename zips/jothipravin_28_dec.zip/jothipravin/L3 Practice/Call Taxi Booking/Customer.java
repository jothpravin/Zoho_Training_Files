public class Customer
{
	public Customer
	{
				
	}
}
