public enum BerthType {
    UB,
    LB,
    MB,
    SU,
    RAC
}
