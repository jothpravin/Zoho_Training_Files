public class Product {
    String product;
    int price;

    public Product(String product, int price) {
        this.product = product;
        this.price = price;
    }
}
