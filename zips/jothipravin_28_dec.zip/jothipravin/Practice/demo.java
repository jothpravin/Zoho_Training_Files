import java.util.*;

class demo
{
	public static void main(String []args)
	{
		Object o = new String("Pravin");
		StringBuffer sb = (StringBuffer)o;
	}
}

