import java.util.List;
import java.util.ArrayList;

class LinkedListDS<T>
{
	List<T> list;
	public LinkedListDS()
	{
		list = new ArrayList<>();
	}
	
	public void add(T a)
	{
		list.add(a);
	}
	
	public void print()
	{
		System.out.println(list);
	}
}

public class LinkedListEx
{
	public static void main(String []args)
	{
		LinkedListDS<Integer> ll = new LinkedListDS<>();
		
		ll.add(10);
		ll.add(20);
		ll.print();
	}
}
