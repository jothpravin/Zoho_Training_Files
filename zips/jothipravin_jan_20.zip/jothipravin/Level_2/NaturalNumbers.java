public class NaturalNumbers
{
	public static void main(String args[])
	{
		System.out.println("The first 10 natural numbers are:");
		for(int i=1;i<=10;i++)
		{
			System.out.println(i);
		}
	}
}

