public class Student
{
	public static void main(String []args)
	{
		S s1 = new S("Pravin", 22, 'A');
		System.out.println(s1.getGrade());
	}
}
