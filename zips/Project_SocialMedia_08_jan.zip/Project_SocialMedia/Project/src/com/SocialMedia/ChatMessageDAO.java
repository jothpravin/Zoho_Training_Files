import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ChatMessageDAO 
{
    private static final String insert_message_query = "INSERT INTO chatmessages (senderid, receiverid, content, timestamp) VALUES (?, ?, ?, ?)";

    public void insertNewMessage(ChatMessage cm)
    {
        Connection con = ConnectionDB.getConnection();
        try(PreparedStatement ps = con.prepareStatement(insert_message_query, Statement.RETURN_GENERATED_KEYS))
        {
            ps.setLong(1, cm.getSenderID());
            ps.setLong(2, cm.getRecieverID());
            ps.setString(3, cm.getContent());
            ps.setTimestamp(4, cm.getTimeStamp());

            int row = ps.executeUpdate();

            if(row > 0)
            {
                ResultSet rs = ps.getGeneratedKeys();
                if(rs.next())
                {
                    cm.setChatID(rs.getLong(1));
                    System.out.println("Successfully message inserted into db");
                }
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}
