import java.sql.Date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Types;

class UserDAO
{
	private static final String user_insert_query = "INSERT INTO users (username, password, email, dob, bio, gender) VALUES (?, ?, ?, ?, ?, ?)";
	private static final String user_online_status = "UPDATE users SET status = 'online' WHERE userid = ?";
	private static final String user_online_status = "UPDATE users SET status = 'offline' WHERE userid = ?";
	private static final String login_query = "SELECT password FROM users WHERE userid = ?";
	private static Connection con = ConnectionDB.getConnection();
	private static PreparedStatement ps = null;
	
	public void addUser(User u)
	{
		try(PreparedStatement ps = con.prepareStatement(user_insert_query, Statement.RETURN_GENERATED_KEYS);)
		{
			Date sqlDate = new Date(u.getDob().getTime());
			ps.setString(1, u.getUserName());
			ps.setString(2, u.getPassword());
			ps.setString(3, u.getEmail());
			ps.setDate(4, sqlDate);
			ps.setString(5, u.getBio());
			ps.setObject(6, u.getGender(), Types.OTHER);
			
			int row = ps.executeUpdate();
			if(row > 0)
			{
				ResultSet rs = ps.getGeneratedKeys();
				if(rs.next())
				{
					u.setUserID(rs.getInt(1));
					System.out.println("Successfully inserted into User table");
				}
			}
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void statusOnline(long userID)
	{
		try(PreparedStatement ps = con.prepareStatement(user_online_status);)
		{
			ps.setLong(1, userID);
			
			int row = ps.executeUpdate();
			if(row > 0)
			{
				System.out.println("User is back to Online");
			}
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void statusOffline(long userID)
	{
		try(PreparedStatement ps = con.prepareStatement(user_offline_status);)
		{
			ps.setLong(1, userID);
			
			int row = ps.executeUpdate();
			if(row > 0)
			{
				System.out.println("User back to Offline");
			}
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
	}
	
	public boolean loginCredential(String emailID, String password)
	{
		try(PreparedStatement ps = con.prepareStatement(login_query);)
		{
			ps.setString(1, emailID);
			
			ResultSet rs = ps.executeQuery();
			if(rs.next() != null)
			{
				return true;
			}
			return false;
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
	}
}
