import java.util.Scanner;
import java.util.Date;

class Post
{
	private long postID;
	private long userID;
	private String content;
	private Date timeStamp;
	private long views;
	
	public Post(long userID, String content, Date timeStamp, long views)
	{
		this.postID = postID;
		this.userID = userID;
		this.content = content;
		this.timeStamp = timeStamp;
		this.views = views; 
	}
	
	public long getPostID() 
	{
		return postID;
	}

	public void setPostID(long postID) 
	{
		this.postID = postID;
	}

	public long getUserID() 
	{
		return userID;
	}

	public String getContent() 
	{
		return content;
	}
	
	public Date getDate() 
	{
		return timeStamp;
	}
	
	public long getViews() 
	{
		return views;
	}
}
