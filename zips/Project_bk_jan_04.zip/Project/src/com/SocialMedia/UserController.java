import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

class UserController
{
	Scanner in = new Scanner(System.in);
	UserDAO userDAO = new UserDAO();
	
	public void signUp()
	{
		try
		{
			System.out.print("Enter the Email ID: ");
			String email = in.next();
			System.out.print("Enter the Password: ");
			String pass = in.next();
			System.out.print("Enter the Student date of birth(dd/mm/yyyy): ");
			String dob = in.next();
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			Date date = formatter.parse(dob);
			System.out.println("\n1.Male\n2.Female\nEnter Gender: ");
			int n = in.nextInt();
			Gender g = null;
			if(n==1)
			{
				g = Gender.male;
			}
			else if(n==2)
			{
				g = Gender.female;
			}
			in.nextLine();
			System.out.print("Enter the userName :");
			String userName = in.nextLine();
			System.out.print("Enter the Bio: ");
			String bio = in.nextLine();
			
			User newUser = new User(userName, pass, email, date, bio, g);
			userDAO.addUser(newUser);
			System.out.println("New User added with ID: " + newUser.getUserID());
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void login()
	{
		System.out.print("Enter the Email ID: ");
		String email = in.next();
		System.out.print("Enter the Password: ");
		String pass = in.next();
		return userDAO.loginCredential(email, pass)
		{
			return true
			System.out.println("Successfully Login");
		}
		else
		{
			System.out.println("Invalid Crendentials");
		}
	}
	
}
