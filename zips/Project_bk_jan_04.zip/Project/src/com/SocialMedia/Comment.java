import java.util.Date;

class Comment
{
	private long commentID;
	private long postID;
	private long userID;
	private Date timeStamp;
	
	public Comment(long postID, long userID, Date timeStamp)
	{
		this.commentID = 0;
		this.postID = postID;
		this.userID = userID;
		this.timeStamp = timeStamp;
	}
	
	public void setCommentID(long commentID)
	{
		this.commentID = commentID;
	}
	
	public long getLikeID()
	{
		return commentID;
	}
	
	public long userID()
	{
		return userID;
	}
	
	public long postID()
	{
		return postID;
	}
	
	public Date getTimeStamp()
	{
		return timeStamp;
	}
}
