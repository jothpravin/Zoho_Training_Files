public class Switch{
	public static void main(String[] args){
		char ch='a';
		switch(ch)
		{
			case 'a':
				System.out.println("Vowel");
				break;
			default:
				System.out.println("Not working");
		}
	}
}
