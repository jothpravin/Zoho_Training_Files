package com.pravin.jai;
import static java.lang.System.*;

public class test
{
	public static void main(String []args)
	{
		out.println("Mubabi");
	}
}

