public class StringMat
{
	
}
