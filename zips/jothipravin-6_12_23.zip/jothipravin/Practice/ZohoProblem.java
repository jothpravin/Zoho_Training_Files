import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

public class ZohoProblem
{
	public static void main(String []args)
	{
		//ArrayList<List<Integer>> listOflist = new ArrayList<List<Integer>>();
		
		//List<Integer> anagram = new List<Integer>();
		//List<Integer> str = new List<Integer>();
		
		String [] arr = new String[]{"eat","ate", "coffee", "bru", "sunrises", "tea"};
		
		String [] temp = new String[arr.length];
		int k=0;
		
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
		
		/*for(int i=0; i<arr.length; i++)
		{
			for(int j=i+1; j<arr.length; j++)
			{
			
			}
		}*/
	}
}
