package Ecommerence;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.SQLException;

public class CustomerDAO
{
	static int CUSTOMER_ID;
	public void addCustomer(Customer customer)
	{
		String query = "INSERT INTO customers (firstname, lastname, email, password, mobile, wallet) VALUES (?, ?, ?, ?, ?, ?)";
		Connection con = ConnectionDB.getConnection();
		try(PreparedStatement ps = con.prepareStatement(query))
		{
			ps.setString(1, customer.getFirstName());
			ps.setString(2, customer.getLastName());
			ps.setString(3, customer.getEmail());
			ps.setString(4, customer.getPassword());
			ps.setLong(5, customer.getMobile_no());
			ps.setLong(6, customer.getWallet());
			
			int row = ps.executeUpdate();
			if(row > 0)
			{
				System.out.println("Successfully New Customer Created..!");
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public Customer getCustomer()
	{
		String query = "SELECT * FROM customer WHERE customerid = ?";
		Connection con = ConnectionDB.getConnection();
		try(PrepaeredStatement ps = con.prepareStatement(query))
		{
			ps.setInt(1, CUSTOMER_ID)
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				Customer customer = new Customer(rs.getString("firstname"),
									   rs.getString("lastname"),
									   rs.getString("email"),
									   rs.getString("password"),
									   rs.getLong("mobile"),
									   rs.getLong("wallet")
									);
				customer.setCustomerId(rs.getInt("customerid"));	
			}
			return customer;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}  
}
