package ECommerence;

import java.util.Scanner;

public class Main 
{
    static
    {
        new Helper();
    }
    static Scanner in = new Scanner(System.in);
    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_BULE = "\u001B[34m";
    public static void main(String[] args) 
    {
        while(true)
		{
			System.out.println(ANSI_BULE+"------------------------------------------------------");
			System.out.println("| Option |            Description                    |");
			System.out.println("------------------------------------------------------");
			System.out.println("|   1    | Login User                                |");
			System.out.println("|   2    | SignUp User                               |");
			System.out.println("|   3    | Exit                                      |");
			System.out.println("------------------------------------------------------"+ANSI_RESET);

			System.out.print(ANSI_YELLOW+"Enter the Option to perform :"+ANSI_RESET);	
			int n = in.nextInt();
			switch(n)
			{
				case 1:
                    break;

                case 2:
                    break;

                case 3:
                    System.out.println("Application exiting..!");
                    System.exit(0);
            }
        }  
    }
}
