package ECommerence;

public class Address 
{
    private int addressId;
    private String address;
    private int customerId;

    public Address(int addressId, String address, int customerId) 
    {
        this.addressId = addressId;
        this.address = address;
        this.customerId = customerId;
    }

    public void setAddressId(int addressId) 
    {
        this.addressId = addressId;
    }

    public int getAddressId() 
    {
        return addressId;
    }

    public String getAddress() 
    {
        return address;
    }

    public int getCustomerId() 
    {
        return customerId;
    }
}
