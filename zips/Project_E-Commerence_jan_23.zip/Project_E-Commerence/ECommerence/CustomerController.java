package ECommerence;

import java.util.List;

public class CustomerController 
{
    private CustomerDAO customerDAO;
    private CustomerView customerView;

    public CustomerController(CustomerDAO customerDAO, CustomerView customerView)
    {
        this.customerDAO = customerDAO;
        this.customerView = customerView;
    }

    public void signUp()
    {
        Customer customer = customerView.newCustomer();
        customerDAO.addCustomer(customer);
    }

    public int login()
    {
        String[] credentials = customerView.credentials();
        if(credentials != null)
        {
            return customerDAO.login(credentials[0], credentials[1]);
        }
        return -1;
    }

    public boolean logout()
    {
        customerDAO.logout();
        customerView.logout();
        return true;
    }

    public void getCustomerName()
    {
        String customerName = customerDAO.getCustomer().getFirstName();
        customerView.getCustomerName(customerName);
    }

    private void showProducts()
    {
        List<String> products = customerDAO.getAllProducts();
        if(products != null)
        {
            customerView.browserProducts(products);
        }
        else
        {
            System.out.println("No products");
        }
    }

    public void buyProduct()
    {
        showProducts();
        int productId = customerView.getProductInput();
        Product product = customerDAO.getProduct(productId);
        if(product != null)
        {
            int input = customerView.getBuyOrCartInput();
            if(input == 1)
            {
                List<Address> addresses = customerDAO.getAllAddress();
                if(addresses.size() > 0)
                {
                    Order order = customerView.newOrder(product, addresses);                 // Get the Order Object from view
                    customerDAO.createOrder(order);                                          // Create the Order with order object
                    double amount = customerDAO.getCustomerWallet() - order.getAmount();     // Get the Current wallet amount and calculate the wallet amount after buyed
                    customerDAO.updateCustomerWallet(amount);                                // Update the wallet amount of customer
                    double income = customerDAO.getMerchantAmount(product.getMerchantId()) + order.getAmount();
                    customerDAO.updateMerchanWallet(income, product.getMerchantId());        // Update the wallet amount of Merchant
                    int stockBalance = customerDAO.getProductStockQuantity(productId) - order.getQuantity();
                    customerDAO.updateStockQuantity(stockBalance, productId);                // Update the Quantity of product
                }
                else
                {
                    System.out.println("First add address then buy");
                    Address address = customerView.newAddress();
                    customerDAO.createAddress(address);
                    buyProduct();
                }
                
            }
            else if(input == 2)
            {
                Cart cart = customerView.newCart(product);
                customerDAO.addToCart(cart);
            }
            else if(input == 0)
            {
                return;
            }
        }
        else
        {
            System.out.println("Invalid product id...");
        }
    }

    public void newAddress()
    {
        Address address = customerView.newAddress();
        customerDAO.createAddress(address);
    }
}
