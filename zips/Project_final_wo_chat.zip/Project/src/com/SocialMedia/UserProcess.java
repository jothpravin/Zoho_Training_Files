interface UserProcess
{

}
