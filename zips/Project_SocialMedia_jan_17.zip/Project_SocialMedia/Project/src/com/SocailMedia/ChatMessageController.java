package SocailMedia;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class ChatMessageController 
{
    ChatMessageDAO chatMessageDAO = new ChatMessageDAO();
    UserDAO userDAO = new UserDAO();
    static Scanner in = new Scanner(System.in); 
    public void sendNewMessage()
    {
        showFriends();
        System.out.println("Enter the friend id to chat :");
        int fid = in.nextInt();
        boolean flag = true;
        while(flag)
        {
            System.out.println("Enter the message :");
            String message = in.nextLine();
            ChatMessage cm = new ChatMessage(UserDAO.USER_ID, fid, message, new Timestamp(new Date().getTime()));
            chatMessageDAO.insertNewMessage(cm);
        }
    }

    public void showMessage()
    {
        
    }

    public boolean showFriends()
    {
        List<User> users = chatMessageDAO.getAllUsers();
		System.out.println("---------------Find-Peoples----------------");
		for(User user : users)
		{
			System.out.println("ID: " + user.getUserID());
			System.out.println("Name: " + user.getUserName());
			System.out.println("-----------------------------------------");
		}
		return true;
    }
}
