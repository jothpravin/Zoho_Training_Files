import java.util.Scanner;

public class CheckSpecifiedNumber
{	
	public static void CheckNum(int a[], int n)
	{
		int count=0;
		for(int i=0;i<n;i++)
		{
			if(a[i] == 65)
			{
				count++;
			}
			else if(a[i] == 77)
			{
				count++;
			}
		}
		if(count>1)
		{
			System.out.println("True");	
		}
		else
		{
			System.out.println("False");
		}
		
	}
	
	public static void main(String args[])
	{
		int ArraySize;
		Scanner num = new Scanner(System.in);
		
		System.out.print("Input number of Array size:");
		ArraySize = num.nextInt();
		
		int array[] = new int[ArraySize];
		
		for(int row=0;row<ArraySize;row++) //To get a Input array number from User
		{	
			array[row]=num.nextInt();
		}
		
		CheckNum(array,ArraySize);
		
	}
}
