package StockTradingSystem;

import java.util.List;
import java.util.Scanner;

public class TradingController 
{
    static Scanner in = new Scanner(System.in);
    private TradingDAO tradingDAO;
    public TradingController(TradingDAO tradingDAO)
    {
        this.tradingDAO = tradingDAO;
    }

    public void createTradingAccount()
    {
        if(!checkTradingAccount())
        {
            System.out.print("Enter the Aadhar number :");
            Long aadharNumber = in.nextLong();
            while(!Validator.isValidAadhar(aadharNumber))
            {
                System.out.print("Enter the Aadhar number :");
                aadharNumber = in.nextLong();
            }
            System.out.print("Enter the PAN card :");
            String pan = in.next();
            while(!Validator.isValidPan(pan))
            {
                System.out.print("Enter the PAN card :");
                pan = in.next();
            }
            System.out.print("Enter the Inital deposit amount: ");
            Double amount = in.nextDouble();
    
            TradingAccount tradingAccount = new TradingAccount(UserDAO.USERID, aadharNumber, pan, amount);
            tradingDAO.createTradingAccount(tradingAccount);
        }
        else
        {
            System.out.println("Already have a trading account!");
        }
    }

    private boolean checkTradingAccount()
    {
        System.out.println("userid: "+UserDAO.USERID);
        return tradingDAO.isTradingAcount(UserDAO.USERID);
    }

    private void showStocks()
    {
        List<Stock> stocks = tradingDAO.getAllStocks();
        for(Stock stock: stocks)
        {
            System.out.println("===========================");
            System.out.println("Stock ID: "+stock.getStockId());
            System.out.println("Stock Name: "+stock.getStockName());
            System.out.println("Stock Price: "+stock.getPrice());
        }
        System.out.println("===========================");   
    }

    private boolean showHoldings()
    {
        List<Holding> holdings = tradingDAO.getAllHoldings();
        if(holdings.size() <= 0)
        {
            return false;
        }
        for(Holding holding: holdings)
        {
            System.out.println("===========================");
            System.out.println("Holding ID: "+holding.getHoldId());
            System.out.println("Stock ID: "+holding.getStockId());
            System.out.println("Stock Name: "+tradingDAO.getStock(holding.getStockId()).getStockName());
            System.out.println("Stock Price: "+holding.getPrice());
            System.out.println("Quantity: "+holding.getQuantity());
            System.out.println("Amount: "+holding.getAmount());
            System.out.println("Date: "+holding.getDate());
        }
        System.out.println("===========================");
        return true;
    }

    public void buyStock()
    {
        if(checkTradingAccount())
        {
            showStocks();
            System.out.print("Enter the stock id to buy: ");
            int stockid = in.nextInt();
            System.out.print("Enter the stock quantity: ");
            int quantity = in.nextInt();
            Stock stock = tradingDAO.getStock(stockid);
            if(stock != null)
            {
                double totalAmount = stock.getPrice() * quantity;
                double currentAmount = getAmount();
                if(totalAmount <= currentAmount)
                {
                    Holding holding = new Holding(TradingDAO.TradingAccountID, stockid, stock.getPrice(), quantity, totalAmount);
                    Transaction transaction = new Transaction(Action.Buy, holding);
                    addHoldings(holding);
                    addTransaction(transaction);
                    updateAmount(currentAmount - totalAmount);
                }
                else
                {
                    System.out.println("Insufficient amount! :" +currentAmount);
                }
            }
            else
            {
                System.out.println("Invalid stock id!");
            }
        }
        else
        {
            System.out.println("Create Trading Account first!");
        }
    }

    public void sellStock() 
    {
        if(checkTradingAccount()) 
        {
            if(!showHoldings())
            {
                System.out.println("No holdings found!");
                return;
            }
            System.out.print("Enter the hold id to sell stock: ");
            int holdid = in.nextInt();
    
            System.out.print("Enter the stock quantity: ");
            int quantity = in.nextInt();
    
            // Check if quantity is non-negative
            if(quantity < 0) 
            {
                System.out.println("Invalid quantity entered!");
                return;
            }
    
            Holding holding = tradingDAO.getHolding(holdid);
    
            if(holding.getQuantity() >= quantity) 
            {
                double currentStockAmount = currentPrice(holding.getStockId()) * quantity;
                double currentTradingAmount = getAmount();
                double userCurrentStockAmount = holding.getAmount();
                double currentProfit = 0.0;
    
                if(userCurrentStockAmount < currentStockAmount) 
                { // profit
                    updateQuantity(holding.getQuantity() - quantity);
                    updateQuantitySelled(quantity);
                    currentProfit = currentStockAmount + currentTradingAmount;
                    updateAmount(currentProfit);
                    holding.setQuantity(holding.getQuantity() - quantity);
                    holding.setQuantitySelled(quantity);
                    System.out.println("Profit: " + (currentStockAmount - userCurrentStockAmount));
                } 
                else 
                { // loss
                    updateQuantity(holding.getQuantity() - quantity);
                    updateQuantitySelled(quantity);
                    currentProfit = currentStockAmount - userCurrentStockAmount + currentTradingAmount;
                    updateAmount(currentProfit);
                    holding.setQuantity(holding.getQuantity() - quantity);
                    holding.setQuantitySelled(quantity);
                    System.out.println("Loss: " + (userCurrentStockAmount - currentStockAmount));
                }
            }
            else 
            {
                System.out.println("Insufficient quantity!");
            }
        } 
        else 
        {
            System.out.println("Create Trading Account first!");
        }
    }

    private double getAmount()
    {
        return tradingDAO.getAmount();
    }

    private double currentPrice(int stockid)
    {
        return tradingDAO.getCurrentStockPrice(stockid);
    }

    public void addHoldings(Holding holding)
    {
        tradingDAO.addNewHolding(holding);
    }
    private void addTransaction(Transaction transaction)
    {
        tradingDAO.addNewTransaction(transaction);
    }

    private void updateAmount(double amount)
    {
        tradingDAO.updateAmount(amount);
    }

    private void updateQuantity(int quantity)
    {
        tradingDAO.updateQuantity(quantity);
    }

    private void updateQuantitySelled(int quantitySelled)
    {
        tradingDAO.updateQuantitySelled(quantitySelled); 
    } 
}
