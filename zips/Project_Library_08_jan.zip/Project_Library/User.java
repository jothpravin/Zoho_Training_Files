class User
{
    private int userID;
    private String userName;
    private String emailID;
    private String password;
    private boolean isAdmin;
    private Gender gender;

    public User(String userName, String emailID, String password, boolean isAdmin, Gender gender)
    {
        this.userID = 0;
        this.userName = userName;
        this.emailID = emailID;
        this.password = password;
        this.gender = gender;
        this.isAdmin = isAdmin;
    }

    public void setUserID(int userID) 
    {
        this.userID = userID;
    }

    public int getUserID() 
    {
        return userID;
    }

    public String getUserName() 
    {
        return userName;
    }

    public String getEmailID() 
    {
        return emailID;
    }

    public String getPassword() 
    {
        return password;
    }

    public boolean isAdmin() 
    {
        return isAdmin;
    }

    public Gender getGender() 
    {
        return gender;
    }

    
}

enum Gender
{
    male,
    female
}