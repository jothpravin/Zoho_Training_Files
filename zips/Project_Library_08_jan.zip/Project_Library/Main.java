import java.util.Scanner;

public class Main 
{
    static Scanner in = new Scanner(System.in);
    public static void main(String []args)
    {
        int n;
        System.out.print("Enter the option to perform :");
        n = in.nextInt();

        while(true)
        {
            switch(n)
            {
                case 1:
                    break;
            }
        }
    }
}
