CREATE TYPE gender_enum AS ENUM('Male', 'Female', 'Other');

CREATE TABLE Users (
    UserID SERIAL PRIMARY KEY,
    Username VARCHAR(50),
    Email VARCHAR(50),
    Password VARCHAR(50),
    isAdmin BOOLEAN,
    Gender gender_enum
);

CREATE TABLE Publishers (
   PublisherID SERIAL PRIMARY KEY,
   PublisherName VARCHAR(100)
);

CREATE TABLE Rack (
   RackID SERIAL PRIMARY KEY,
   RackName VARCHAR(50)
);

CREATE TABLE Book (
    BookID SERIAL PRIMARY KEY,
    BookName VARCHAR(100),
    Author VARCHAR(100),
    PublisherID INT REFERENCES Publishers(PublisherID),
    Available INT
);

CREATE TABLE BookCopy (
   BC_ID SERIAL PRIMARY KEY,
   BookID INT REFERENCES Book(BookID),
   RackID INT REFERENCES Rack(RackID),
   Book_Token_No SERIAL 
);

CREATE TABLE BookIssue (    
  BI_ID SERIAL PRIMARY KEY,
  UserID INT REFERENCES Users(UserID),
  BC_ID INT REFERENCES BookCopy(BC_ID), 
  DateOfIssue DATE, 
  ReturnDate DATE, 
  Fine DECIMAL
);