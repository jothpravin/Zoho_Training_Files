public class Book 
{
    private int bookID;
    private String bookName;
    private String authorName;
    private int publisherID;

    public Book(String bookName, String authorName, int publisherID) 
    {
        this.bookID = 0;
        this.bookName = bookName;
        this.authorName = authorName;
        this.publisherID = publisherID;
    }

    public void setBookID(int bookID) 
    {
        this.bookID = bookID;
    }

    public int getBookID() 
    {
        return bookID;
    }

    public String getBookName() 
    {
        return bookName;
    }

    public String getAuthorName() 
    {
        return authorName;
    }

    public int getPublisherID() 
    {
        return publisherID;
    }
    
    
    
}
