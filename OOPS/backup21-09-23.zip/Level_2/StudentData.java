import java.util.Scanner;

public class StudentData
{
	public static void main(String []args)
	{
		String name;
		int noOfStudents;
		String subjects[] = new String[]{"Tamil", "English", "Maths", "Science", "Social"};
		StudentManager studentManager = new StudentManager(10);
		Scanner obj = new Scanner(System.in);
		System.out.print("Enter the noOfStudents :");
		noOfStudents = obj.nextInt();
		
		for(int i=1; i<=noOfStudents; i++)
		{
			int []marks = new int[5];
			System.out.print("Enter the student name: ");
			name = obj.next();
			System.out.println("<-------Enter the student marks respectively------>");
			for(int j=0; j<5; j++)
			{
				System.out.print("Enter "+subjects[j]+" Mark: ");
				marks[j] = obj.nextInt();
			}
			studentManager.addStudent(new Student(i, name, subjects, marks));
			System.out.println();
		}
		obj.close();
		studentManager.printAllStudents();
		studentManager.printAllSubjects();
		studentManager.passedStudents();
		studentManager.failedStudents();
		studentManager.TopFiveStudent();
		for(int i=0; i<subjects.length; i++)
		studentManager.subjectsWithHighestMark(subjects[i]);
	}
}
