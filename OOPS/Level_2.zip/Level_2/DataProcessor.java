class DataProcessor
{
	private static final int MaxCampaign = 100;
	private static final int MaxDonator = 100;
	
	Campaign[] cam;
	int campaignCount;
	Donator[] don;
	int donatorCount;
	
	DataProcessor()
	{
		cam = new Campaign[MaxCampaign];
		campaignCount=0;
		don = new Donator[MaxDonator];
		donatorCount=0;
	}
	
	public Campaign[] getCampaign()
	{
		return cam;
	}
	
	public void addCampaign(Campaign campaign)
	{
		if(campaignCount<MaxCampaign)
		{
			cam[campaignCount++] = campaign;
		}
		else
		{
			System.out.println("Maximum campaigns reached");
		}
	}
	
	public void addDonation(Donator donator)
	{
		if(donatorCount<MaxDonator)
		{
			don[donatorCount++] = donator;
		}
		else
		{
			System.out.println("Maximum Donators reached");
		}
	}
	
	public void listCampaigns()
	{
		int count=0;
		for(Campaign c: cam)
		{
			if(c!=null)
			{	
				System.out.println(c.toString());
				System.out.println("<---------------->");
			}
		}
		if(count==0)
		{
			System.out.println("There is no campaigns");
		}
	}
	
	public void listDonators()
	{		
		int count = 0;
		for(Donator d: don)
		{
			if(d!=null)
			{	
				count++;
				System.out.println(d.toString());
				System.out.println("<---------------->");
			}
		}
		if(count==0)
		{
			System.out.println("There is no Donators");
		}
	}
	
	
}
