import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

public class MainCampaign
{
	public static void main(String []args) throws ParseException
	{
		int choose;
		Scanner obj = new Scanner(System.in);
		DataProcessor dp = new DataProcessor();
		SimpleDateFormat fDate = new SimpleDateFormat("dd/mm/yyyy");
		
		while(true)
		{
			System.out.println("------|Menu|------");
			System.out.println(" 1.Add Campaign\n 2.Add Donators\n 3.List Campaigns\n 4.List Donators\n 5.exit");
			System.out.print("Pick an Option: ");
			choose = obj.nextInt();
			
			switch(choose)
			{
				case 1:
					System.out.print("Enter the Owner: ");
					String s1 = obj.next();
					System.out.print("Enter the Campaign Name: ");
					String s2 = obj.next();
					System.out.print("Enter the Launch Date - like this dd/MM/yyyy :");
					String s3 = obj.next();
					Date lDate = fDate.parse(s3);
					System.out.print("Enter the DeadLine Date - like this dd/MM/yyyy: ");
					String s4 = obj.next();
					Date dDate = fDate.parse(s4);
					System.out.print("Enter the Fund Raising goal: ");
					double d = obj.nextDouble();
					System.out.print("Enter the Description for campaign: ");
					String s5 = obj.next();
					System.out.print("Enter the Events : ");
					String s6 = obj.next();
					
					Campaign campaign = new Campaign(s1, s2, lDate, dDate, d, s5, s6);
					
					dp.addCampaign(campaign);
					System.out.println("Campaign Sucessfully Created");
					break;
				
				case 2:
					System.out.print("Campaign Names: ");
					int i=1,count=0;
					Campaign []cl = dp.getCampaign();
					for(int j=0 ; j<dp.getCampaign().length; j++)
					{
						if(cl[j]!=null)
						{
							System.out.println((i++)+"."+cl[j].getCampaignName());
							count++;
						}
					}
					
					if(count!=0)
					{
						System.out.println("<----Choose the campaign: ");
						int choice = obj.nextInt()-1;
						Campaign[] cn = dp.getCampaign();
						String s11 = cn[choice].getCampaignName();
						
						System.out.print("Enter the Contributor Name: ");
						String s10 = obj.next();
						
						System.out.print("Enter the Payment Method: ");
						String s12 = obj.next();
						System.out.print("Enter the Description: ");
						String s13 = obj.next();
						System.out.print("Enter the Email ID: ");
						String s14 = obj.next();
						System.out.print("Enter the Donation amount: ");
						double d1 = obj.nextDouble();
						System.out.print("Enter the Payment Date - like this dd/MM/yyyy: ");
						String s15 = obj.next();
						Date pDate = fDate.parse(s15);
						
						boolean validDate = false;
						
						for(Campaign c : dp.getCampaign())
						{
							if(c.getCampaignName().equals(s11))
							{
								Date lanuch = c.getLanuchDate();
								Date deadLine = c.getFundraiserDeadline();
								
								if(pDate.after(lanuch) && pDate.before(deadLine))
								{
									c.addAmount(d1);
									validDate = true;
									break;
								}
							}
						}
						
						if(validDate)
						{
							Donator donator = new Donator(s10, s11, s12, s13, s14, d1, pDate);
							dp.addDonation(donator);
							System.out.println("Donation is successfully Credited");
							break;
						}
						else
						{
							System.out.println("Campaign has ended, you can donate some other campaign");
							break;
						}
					}
					else
					{
						System.out.println("There is no Campaign");
					}
				
				case 3:
					System.out.println("=====>Campaigns Lis<=====");
					dp.listCampaigns();
					break;
					
				case 4:
					System.out.println("=====>Donators Lis<=====");
					dp.listDonators();
					break;
					
				case 5:
					System.exit(0);
					
				default :
					System.out.println("Invalid Options");
			}
		}
	}
}
