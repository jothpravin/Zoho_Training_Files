import java.util.Date;

class Campaign
{
	private String owner;
	private String campaignName;
	private String status;
	private Date lanuchDate;
	private Date fundraiserDeadline;
	private double fundraisingGoal;
	private double amountRaised;
	private String description;
	private String event;
	
	Campaign(String owner, String campaignName, Date lanuchDate, Date fundraiserDeadline, double fundraisingGoal, String decription, String event)
	{
		this.owner = owner;
		this.campaignName = campaignName;
		this.status = "Not started";
		this.lanuchDate = lanuchDate;
		this.fundraiserDeadline = fundraiserDeadline;
		this.fundraisingGoal = fundraisingGoal;
		this.amountRaised = 0;
		this.description = description;
		this.event = event; 
	}
	
	public String getCampaignName()
	{
		return campaignName;
	}
	
	public String getStatus()
	{
		return status;
	}
	
	public Date getLanuchDate()
	{
		return lanuchDate;
	}
	
	public Date getFundraiserDeadline()
	{
		return fundraiserDeadline;
	}
	
	public double getFundraisingGoal()
	{
		return fundraisingGoal;
	}
	
	public void setStatus(String status)
	{
		this.status = status;
	}
	
	public void addAmount(double amount)
	{
		amountRaised += amount;
	}
	
	public String toString()
	{
		return "CampaignName: "+campaignName+"\nOwner: "+owner+"\nstatus: "+status+"\nLanuchDate: "+lanuchDate+"\nFundraiserDeadline: "+fundraiserDeadline+ "\nAmountRaised: "+amountRaised+ "\nDescription :"+description+"\nEvent: "+event;
	}
}
